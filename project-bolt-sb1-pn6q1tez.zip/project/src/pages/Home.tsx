import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';
import { Clock, Shield, Award, ThumbsUp } from 'lucide-react';
import HeroSection from '../components/HeroSection';
import CarCard from '../components/CarCard';
import { fetchFeaturedCars } from '../services/api';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
  available: boolean;
}

const Home: React.FC = () => {
  const [featuredCars, setFeaturedCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadFeaturedCars = async () => {
      try {
        const cars = await fetchFeaturedCars();
        setFeaturedCars(cars.slice(0, 3));
      } catch (error) {
        console.error('Failed to load featured cars:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadFeaturedCars();
  }, []);
  
  return (
    <div>
      <HeroSection 
        title="Premium Car Rental Experience"
        subtitle="Choose from our extensive fleet of luxury, sports, and economy vehicles"
      />
      
      {/* Featured Cars Section */}
      <Container className="py-5">
        <h2 className="text-center mb-4">Featured Vehicles</h2>
        <p className="text-center text-muted mb-5">Explore our most popular rental options</p>
        
        {loading ? (
          <div className="text-center py-5">Loading featured cars...</div>
        ) : (
          <Row className="g-4">
            {featuredCars.map(car => (
              <Col key={car.id} md={4}>
                <CarCard {...car} />
              </Col>
            ))}
          </Row>
        )}
      </Container>
      
      {/* Why Choose Us Section */}
      <section className="py-5 bg-light">
        <Container>
          <h2 className="text-center mb-4">Why Choose Drive Elite?</h2>
          <p className="text-center text-muted mb-5">Experience the difference with our premium car rental service</p>
          
          <Row className="g-4">
            <Col md={3} sm={6}>
              <Card className="h-100 border-0 text-center p-3 shadow-sm">
                <div className="d-flex justify-content-center mb-3">
                  <div className="bg-primary bg-opacity-10 p-3 rounded-circle">
                    <Clock size={28} className="text-primary" />
                  </div>
                </div>
                <Card.Body>
                  <h5>Quick Booking</h5>
                  <p className="text-muted">Reserve your car in minutes with our streamlined booking process.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={3} sm={6}>
              <Card className="h-100 border-0 text-center p-3 shadow-sm">
                <div className="d-flex justify-content-center mb-3">
                  <div className="bg-primary bg-opacity-10 p-3 rounded-circle">
                    <Shield size={28} className="text-primary" />
                  </div>
                </div>
                <Card.Body>
                  <h5>Quality Assured</h5>
                  <p className="text-muted">All our vehicles undergo thorough inspections for your safety.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={3} sm={6}>
              <Card className="h-100 border-0 text-center p-3 shadow-sm">
                <div className="d-flex justify-content-center mb-3">
                  <div className="bg-primary bg-opacity-10 p-3 rounded-circle">
                    <Award size={28} className="text-primary" />
                  </div>
                </div>
                <Card.Body>
                  <h5>Premium Selection</h5>
                  <p className="text-muted">Choose from the latest models of luxury and performance vehicles.</p>
                </Card.Body>
              </Card>
            </Col>
            
            <Col md={3} sm={6}>
              <Card className="h-100 border-0 text-center p-3 shadow-sm">
                <div className="d-flex justify-content-center mb-3">
                  <div className="bg-primary bg-opacity-10 p-3 rounded-circle">
                    <ThumbsUp size={28} className="text-primary" />
                  </div>
                </div>
                <Card.Body>
                  <h5>24/7 Support</h5>
                  <p className="text-muted">Our customer service team is always available to assist you.</p>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>
      
      {/* How It Works Section */}
      <section className="py-5">
        <Container>
          <h2 className="text-center mb-4">How It Works</h2>
          <p className="text-center text-muted mb-5">Renting a car with us is simple and straightforward</p>
          
          <Row className="g-4">
            <Col md={4}>
              <div className="text-center p-3">
                <div className="bg-primary rounded-circle d-inline-flex justify-content-center align-items-center mb-3" 
                  style={{ width: '60px', height: '60px', color: 'white' }}>
                  1
                </div>
                <h4 className="mt-3">Select Your Car</h4>
                <p className="text-muted">Browse our collection and choose a vehicle that suits your needs.</p>
              </div>
            </Col>
            
            <Col md={4}>
              <div className="text-center p-3">
                <div className="bg-primary rounded-circle d-inline-flex justify-content-center align-items-center mb-3" 
                  style={{ width: '60px', height: '60px', color: 'white' }}>
                  2
                </div>
                <h4 className="mt-3">Book & Pay</h4>
                <p className="text-muted">Complete your reservation and payment through our secure system.</p>
              </div>
            </Col>
            
            <Col md={4}>
              <div className="text-center p-3">
                <div className="bg-primary rounded-circle d-inline-flex justify-content-center align-items-center mb-3" 
                  style={{ width: '60px', height: '60px', color: 'white' }}>
                  3
                </div>
                <h4 className="mt-3">Enjoy Your Ride</h4>
                <p className="text-muted">Pick up your car and enjoy your journey with premium comfort.</p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </div>
  );
};

export default Home;
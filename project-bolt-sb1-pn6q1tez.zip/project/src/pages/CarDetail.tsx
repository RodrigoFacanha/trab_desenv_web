import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Container, Row, Col, Badge, Button, 
  ListGroup, Alert, Card 
} from 'react-bootstrap';
import { 
  Calendar, DollarSign, Check, 
  Info, Users, Fuel, Gauge, MapPin
} from 'lucide-react';
import { UserContext } from '../contexts/UserContext';
import { fetchCarById } from '../services/api';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
  available: boolean;
  features: string[];
  description: string;
}

const CarDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [car, setCar] = useState<Car | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  
  useEffect(() => {
    const loadCar = async () => {
      try {
        setLoading(true);
        const carId = parseInt(id || '0');
        const carData = await fetchCarById(carId);
        setCar(carData);
        setError(null);
      } catch (err) {
        setError('Failed to load car details. Please try again later.');
        console.error('Error fetching car:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (id) {
      loadCar();
    }
  }, [id]);
  
  const handleBookNow = () => {
    if (!user) {
      navigate('/login', { state: { redirect: `/booking/${id}` } });
    } else {
      navigate(`/booking/${id}`);
    }
  };
  
  if (loading) {
    return (
      <Container className="py-5 text-center">
        <div>Loading car details...</div>
      </Container>
    );
  }
  
  if (error || !car) {
    return (
      <Container className="py-5">
        <Alert variant="danger">
          {error || 'Car not found. Please try another vehicle.'}
        </Alert>
      </Container>
    );
  }
  
  return (
    <Container className="py-5 fade-in">
      <Row>
        <Col lg={8}>
          {/* Car Image */}
          <img 
            src={car.images[0]} 
            alt={`${car.brand} ${car.model}`} 
            className="car-image-main mb-4 shadow"
          />
          
          {/* Car Details */}
          <div className="bg-white p-4 rounded shadow-sm mb-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h1 className="mb-0">{car.brand} {car.model}</h1>
              <Badge bg={car.available ? 'success' : 'danger'} className="px-3 py-2">
                {car.available ? 'Available' : 'Unavailable'}
              </Badge>
            </div>
            
            <div className="mb-4">
              <Badge bg="light" text="dark" className="me-2 px-3 py-2">
                {car.year}
              </Badge>
              <Badge bg="light" text="dark" className="px-3 py-2">
                {car.type}
              </Badge>
            </div>
            
            <h5 className="mb-3">Description</h5>
            <p>{car.description}</p>
            
            <h5 className="mb-3 mt-4">Features</h5>
            <div className="mb-4">
              {car.features.map((feature, index) => (
                <span key={index} className="badge-feature">
                  <Check size={16} className="text-primary me-1" />
                  {feature}
                </span>
              ))}
            </div>
            
            <h5 className="mb-3 mt-4">Specifications</h5>
            <Row className="g-3">
              <Col md={6}>
                <Card className="border-0 bg-light">
                  <Card.Body className="d-flex align-items-center">
                    <Users size={20} className="text-primary me-2" />
                    <div>
                      <small className="text-muted d-block">Passengers</small>
                      <strong>5 People</strong>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={6}>
                <Card className="border-0 bg-light">
                  <Card.Body className="d-flex align-items-center">
                    <Fuel size={20} className="text-primary me-2" />
                    <div>
                      <small className="text-muted d-block">Fuel Type</small>
                      <strong>Gasoline</strong>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={6}>
                <Card className="border-0 bg-light">
                  <Card.Body className="d-flex align-items-center">
                    <Gauge size={20} className="text-primary me-2" />
                    <div>
                      <small className="text-muted d-block">Mileage</small>
                      <strong>Unlimited</strong>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={6}>
                <Card className="border-0 bg-light">
                  <Card.Body className="d-flex align-items-center">
                    <MapPin size={20} className="text-primary me-2" />
                    <div>
                      <small className="text-muted d-block">Pickup Location</small>
                      <strong>Main Branch</strong>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </div>
        </Col>
        
        <Col lg={4}>
          {/* Booking Card */}
          <Card className="sticky-top shadow-sm border-0" style={{ top: '20px' }}>
            <Card.Body>
              <h4 className="mb-4">Rental Summary</h4>
              
              <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="d-flex align-items-center">
                  <DollarSign size={24} className="text-primary" />
                  <span className="fs-2 fw-bold">${car.price}</span>
                </div>
                <span className="text-muted">per day</span>
              </div>
              
              <ListGroup variant="flush" className="mb-4">
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0">
                  <span>Security Deposit</span>
                  <span>$500</span>
                </ListGroup.Item>
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0">
                  <span>Insurance</span>
                  <span>Included</span>
                </ListGroup.Item>
                <ListGroup.Item className="d-flex justify-content-between align-items-center px-0">
                  <span>Unlimited Mileage</span>
                  <span>Included</span>
                </ListGroup.Item>
              </ListGroup>
              
              <Alert variant="info" className="d-flex align-items-start mb-4">
                <Info size={18} className="me-2 mt-1 flex-shrink-0" />
                <small>
                  Free cancellation up to 24 hours before pickup. Credit card is required for booking.
                </small>
              </Alert>
              
              <Button 
                variant="primary" 
                size="lg" 
                className="w-100 d-flex align-items-center justify-content-center"
                onClick={handleBookNow}
                disabled={!car.available}
              >
                <Calendar size={18} className="me-2" />
                {car.available ? 'Book Now' : 'Not Available'}
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default CarDetail;
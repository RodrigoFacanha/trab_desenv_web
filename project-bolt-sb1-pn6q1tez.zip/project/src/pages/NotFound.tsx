import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { Home, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  const navigate = useNavigate();
  
  return (
    <Container className="py-5 text-center fade-in">
      <div className="p-5">
        <h1 className="display-1 fw-bold text-primary">404</h1>
        <h2 className="mb-4">Page Not Found</h2>
        <p className="text-muted mb-5">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <div className="d-flex justify-content-center gap-3">
          <Button 
            variant="primary" 
            className="d-flex align-items-center"
            onClick={() => navigate('/')}
          >
            <Home size={18} className="me-2" />
            Back to Home
          </Button>
          <Button 
            variant="outline-secondary" 
            className="d-flex align-items-center"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft size={18} className="me-2" />
            Go Back
          </Button>
        </div>
      </div>
    </Container>
  );
};

export default NotFound;
import React, { useState, useEffect, useContext } from 'react';
import { 
  Container, Row, Col, Table, Button, 
  Form, Modal, Alert, Badge, Card
} from 'react-bootstrap';
import { 
  Edit, Trash, Plus, Car as CarIcon,
  Users, Calendar, DollarSign 
} from 'lucide-react';
import { UserContext } from '../contexts/UserContext';
import { 
  fetchCars, fetchBookings, fetchUsers,
  createCar, updateCar, deleteCar
} from '../services/api';
import { useNavigate } from 'react-router-dom';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
  available: boolean;
  features: string[];
  description: string;
}

interface User {
  id: number;
  name: string;
  email: string;
  role: string;
}

interface Booking {
  id: number;
  carId: number;
  userId: number;
  startDate: string;
  endDate: string;
  totalPrice: number;
  status: string;
  createdAt: string;
}

const AdminDashboard: React.FC = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  
  // Data states
  const [cars, setCars] = useState<Car[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // UI states
  const [activeTab, setActiveTab] = useState('cars');
  const [showCarModal, setShowCarModal] = useState(false);
  const [currentCar, setCurrentCar] = useState<Car | null>(null);
  const [carFormData, setCarFormData] = useState({
    brand: '',
    model: '',
    year: new Date().getFullYear(),
    type: 'Sedan',
    price: 50,
    images: [''],
    features: [''],
    description: ''
  });
  
  useEffect(() => {
    // Redirect if user is not admin
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    
    const loadData = async () => {
      try {
        setLoading(true);
        
        const [carsData, bookingsData, usersData] = await Promise.all([
          fetchCars(),
          fetchBookings(),
          fetchUsers()
        ]);
        
        setCars(carsData);
        setBookings(bookingsData);
        setUsers(usersData);
        
        setError(null);
      } catch (err) {
        setError('Failed to load data. Please refresh the page.');
        console.error('Error fetching admin data:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [user, navigate]);
  
  const handleCarChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCarFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFeatureChange = (index: number, value: string) => {
    const updatedFeatures = [...carFormData.features];
    updatedFeatures[index] = value;
    setCarFormData(prev => ({ ...prev, features: updatedFeatures }));
  };
  
  const addFeature = () => {
    setCarFormData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };
  
  const removeFeature = (index: number) => {
    const updatedFeatures = [...carFormData.features];
    updatedFeatures.splice(index, 1);
    setCarFormData(prev => ({ ...prev, features: updatedFeatures }));
  };
  
  const handleImageChange = (index: number, value: string) => {
    const updatedImages = [...carFormData.images];
    updatedImages[index] = value;
    setCarFormData(prev => ({ ...prev, images: updatedImages }));
  };
  
  const addImage = () => {
    setCarFormData(prev => ({
      ...prev,
      images: [...prev.images, '']
    }));
  };
  
  const removeImage = (index: number) => {
    const updatedImages = [...carFormData.images];
    updatedImages.splice(index, 1);
    setCarFormData(prev => ({ ...prev, images: updatedImages }));
  };
  
  const handleAddEditCar = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Filter out empty features
      const cleanedFeatures = carFormData.features.filter(f => f.trim() !== '');
      // Filter out empty images
      const cleanedImages = carFormData.images.filter(img => img.trim() !== '');
      
      if (cleanedImages.length === 0) {
        setError('At least one image URL is required.');
        return;
      }
      
      const carData = {
        ...carFormData,
        features: cleanedFeatures,
        images: cleanedImages,
        price: Number(carFormData.price),
        year: Number(carFormData.year)
      };
      
      if (currentCar) {
        // Update existing car
        const updatedCar = await updateCar(currentCar.id, carData);
        setCars(cars.map(car => car.id === currentCar.id ? updatedCar : car));
      } else {
        // Create new car
        const newCar = await createCar(carData);
        setCars([...cars, newCar]);
      }
      
      setShowCarModal(false);
      setCurrentCar(null);
      setError(null);
    } catch (err) {
      setError('Failed to save car. Please try again.');
      console.error('Error saving car:', err);
    }
  };
  
  const handleEditCar = (car: Car) => {
    setCurrentCar(car);
    setCarFormData({
      brand: car.brand,
      model: car.model,
      year: car.year,
      type: car.type,
      price: car.price,
      images: [...car.images],
      features: [...car.features],
      description: car.description
    });
    setShowCarModal(true);
  };
  
  const handleDeleteCar = async (carId: number) => {
    if (window.confirm('Are you sure you want to delete this car?')) {
      try {
        await deleteCar(carId);
        setCars(cars.filter(car => car.id !== carId));
      } catch (err) {
        setError('Failed to delete car. Please try again.');
        console.error('Error deleting car:', err);
      }
    }
  };
  
  const handleAddNewCar = () => {
    setCurrentCar(null);
    setCarFormData({
      brand: '',
      model: '',
      year: new Date().getFullYear(),
      type: 'Sedan',
      price: 50,
      images: [''],
      features: [''],
      description: ''
    });
    setShowCarModal(true);
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  if (loading) {
    return (
      <Container className="py-5 text-center">
        <div>Loading admin dashboard...</div>
      </Container>
    );
  }
  
  return (
    <Container className="py-5 fade-in">
      <h1 className="mb-4">Admin Dashboard</h1>
      
      {error && (
        <Alert variant="danger" className="mb-4">{error}</Alert>
      )}
      
      {/* Dashboard Summary */}
      <Row className="mb-4 g-3">
        <Col md={4}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="p-3 bg-primary bg-opacity-10 rounded-circle me-3">
                <CarIcon size={24} className="text-primary" />
              </div>
              <div>
                <h6 className="mb-0 text-muted">Total Cars</h6>
                <h3 className="mb-0">{cars.length}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="p-3 bg-success bg-opacity-10 rounded-circle me-3">
                <Users size={24} className="text-success" />
              </div>
              <div>
                <h6 className="mb-0 text-muted">Total Users</h6>
                <h3 className="mb-0">{users.length}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="d-flex align-items-center">
              <div className="p-3 bg-info bg-opacity-10 rounded-circle me-3">
                <Calendar size={24} className="text-info" />
              </div>
              <div>
                <h6 className="mb-0 text-muted">Active Bookings</h6>
                <h3 className="mb-0">{bookings.length}</h3>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
      
      {/* Tab Navigation */}
      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'cars' ? 'active' : ''}`}
            onClick={() => setActiveTab('cars')}
          >
            Cars
          </button>
        </li>
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'bookings' ? 'active' : ''}`}
            onClick={() => setActiveTab('bookings')}
          >
            Bookings
          </button>
        </li>
        <li className="nav-item">
          <button 
            className={`nav-link ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            Users
          </button>
        </li>
      </ul>
      
      {/* Cars Tab */}
      {activeTab === 'cars' && (
        <div>
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h2>Car Inventory</h2>
            <Button 
              variant="primary" 
              className="d-flex align-items-center"
              onClick={handleAddNewCar}
            >
              <Plus size={18} className="me-1" />
              Add New Car
            </Button>
          </div>
          
          <div className="table-responsive">
            <Table hover className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Brand & Model</th>
                  <th>Year</th>
                  <th>Type</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {cars.map(car => (
                  <tr key={car.id}>
                    <td>{car.id}</td>
                    <td>
                      <img 
                        src={car.images[0]} 
                        alt={car.brand} 
                        style={{ width: '60px', height: '40px', objectFit: 'cover' }}
                        className="rounded"
                      />
                    </td>
                    <td>{car.brand} {car.model}</td>
                    <td>{car.year}</td>
                    <td>{car.type}</td>
                    <td>${car.price}/day</td>
                    <td>
                      <Badge bg={car.available ? 'success' : 'danger'}>
                        {car.available ? 'Available' : 'Booked'}
                      </Badge>
                    </td>
                    <td>
                      <Button 
                        variant="outline-primary" 
                        size="sm" 
                        className="me-2"
                        onClick={() => handleEditCar(car)}
                      >
                        <Edit size={16} />
                      </Button>
                      <Button 
                        variant="outline-danger" 
                        size="sm"
                        onClick={() => handleDeleteCar(car.id)}
                      >
                        <Trash size={16} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      )}
      
      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div>
          <h2 className="mb-4">Booking Management</h2>
          
          <div className="table-responsive">
            <Table hover className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Car</th>
                  <th>User</th>
                  <th>Dates</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map(booking => {
                  const car = cars.find(c => c.id === booking.carId);
                  const user = users.find(u => u.id === booking.userId);
                  
                  return (
                    <tr key={booking.id}>
                      <td>{booking.id}</td>
                      <td>
                        {car ? `${car.brand} ${car.model}` : `Car #${booking.carId}`}
                      </td>
                      <td>
                        {user ? user.name : `User #${booking.userId}`}
                      </td>
                      <td>
                        {formatDate(booking.startDate)} - {formatDate(booking.endDate)}
                      </td>
                      <td>
                        <DollarSign size={16} className="text-success" />
                        {booking.totalPrice}
                      </td>
                      <td>
                        <Badge bg="success">
                          {booking.status}
                        </Badge>
                      </td>
                      <td>{formatDate(booking.createdAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </div>
        </div>
      )}
      
      {/* Users Tab */}
      {activeTab === 'users' && (
        <div>
          <h2 className="mb-4">User Management</h2>
          
          <div className="table-responsive">
            <Table hover className="admin-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Role</th>
                </tr>
              </thead>
              <tbody>
                {users.map(user => (
                  <tr key={user.id}>
                    <td>{user.id}</td>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>
                      <Badge bg={user.role === 'admin' ? 'primary' : 'secondary'}>
                        {user.role}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      )}
      
      {/* Car Add/Edit Modal */}
      <Modal show={showCarModal} onHide={() => setShowCarModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>{currentCar ? 'Edit Car' : 'Add New Car'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleAddEditCar}>
            <Row className="mb-3">
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Brand</Form.Label>
                  <Form.Control
                    type="text"
                    name="brand"
                    value={carFormData.brand}
                    onChange={handleCarChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Model</Form.Label>
                  <Form.Control
                    type="text"
                    name="model"
                    value={carFormData.model}
                    onChange={handleCarChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            
            <Row className="mb-3">
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Year</Form.Label>
                  <Form.Control
                    type="number"
                    name="year"
                    value={carFormData.year}
                    onChange={handleCarChange}
                    min={2000}
                    max={2030}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Type</Form.Label>
                  <Form.Select
                    name="type"
                    value={carFormData.type}
                    onChange={handleCarChange}
                    required
                  >
                    <option value="Sedan">Sedan</option>
                    <option value="SUV">SUV</option>
                    <option value="Luxury">Luxury</option>
                    <option value="Sports">Sports</option>
                    <option value="Truck">Truck</option>
                  </Form.Select>
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>Price per Day</Form.Label>
                  <Form.Control
                    type="number"
                    name="price"
                    value={carFormData.price}
                    onChange={handleCarChange}
                    min={1}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                name="description"
                value={carFormData.description}
                onChange={handleCarChange}
                rows={3}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Images</Form.Label>
              {carFormData.images.map((image, index) => (
                <div key={index} className="d-flex mb-2">
                  <Form.Control
                    type="text"
                    value={image}
                    onChange={(e) => handleImageChange(index, e.target.value)}
                    placeholder="Image URL"
                    className="me-2"
                  />
                  {carFormData.images.length > 1 && (
                    <Button 
                      variant="outline-danger" 
                      onClick={() => removeImage(index)}
                      className="flex-shrink-0"
                    >
                      <Trash size={16} />
                    </Button>
                  )}
                </div>
              ))}
              <Button 
                variant="outline-primary" 
                onClick={addImage}
                className="mt-2"
              >
                <Plus size={16} className="me-1" />
                Add Image
              </Button>
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Features</Form.Label>
              {carFormData.features.map((feature, index) => (
                <div key={index} className="d-flex mb-2">
                  <Form.Control
                    type="text"
                    value={feature}
                    onChange={(e) => handleFeatureChange(index, e.target.value)}
                    placeholder="Feature"
                    className="me-2"
                  />
                  {carFormData.features.length > 1 && (
                    <Button 
                      variant="outline-danger" 
                      onClick={() => removeFeature(index)}
                      className="flex-shrink-0"
                    >
                      <Trash size={16} />
                    </Button>
                  )}
                </div>
              ))}
              <Button 
                variant="outline-primary" 
                onClick={addFeature}
                className="mt-2"
              >
                <Plus size={16} className="me-1" />
                Add Feature
              </Button>
            </Form.Group>
            
            <div className="d-flex justify-content-end mt-4">
              <Button variant="secondary" onClick={() => setShowCarModal(false)} className="me-2">
                Cancel
              </Button>
              <Button variant="primary" type="submit">
                {currentCar ? 'Update Car' : 'Add Car'}
              </Button>
            </div>
          </Form>
        </Modal.Body>
      </Modal>
    </Container>
  );
};

export default AdminDashboard;
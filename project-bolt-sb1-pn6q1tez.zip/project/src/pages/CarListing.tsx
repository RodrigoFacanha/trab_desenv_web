import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Alert } from 'react-bootstrap';
import SearchFilter from '../components/SearchFilter';
import CarCard from '../components/CarCard';
import { fetchCars } from '../services/api';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
  available: boolean;
}

interface FilterValues {
  search: string;
  type: string;
  priceRange: number;
  sortBy: string;
}

const CarListing: React.FC = () => {
  const [cars, setCars] = useState<Car[]>([]);
  const [filteredCars, setFilteredCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const loadCars = async () => {
      try {
        setLoading(true);
        const carData = await fetchCars();
        setCars(carData);
        setFilteredCars(carData);
        setError(null);
      } catch (err) {
        setError('Failed to load cars. Please try again later.');
        console.error('Error fetching cars:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadCars();
  }, []);
  
  const handleFilter = (filters: FilterValues) => {
    let results = [...cars];
    
    // Filter by search term
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      results = results.filter(car => 
        car.brand.toLowerCase().includes(searchTerm) || 
        car.model.toLowerCase().includes(searchTerm)
      );
    }
    
    // Filter by type
    if (filters.type) {
      results = results.filter(car => car.type === filters.type);
    }
    
    // Filter by price range
    results = results.filter(car => car.price <= filters.priceRange);
    
    // Sort results
    if (filters.sortBy === 'priceLow') {
      results.sort((a, b) => a.price - b.price);
    } else if (filters.sortBy === 'priceHigh') {
      results.sort((a, b) => b.price - a.price);
    } else if (filters.sortBy === 'newest') {
      results.sort((a, b) => b.year - a.year);
    }
    
    setFilteredCars(results);
  };
  
  return (
    <Container className="py-5">
      <h1 className="mb-4">Browse Our Fleet</h1>
      
      <SearchFilter onFilter={handleFilter} />
      
      {error && (
        <Alert variant="danger">{error}</Alert>
      )}
      
      {loading ? (
        <div className="text-center py-5">Loading cars...</div>
      ) : filteredCars.length > 0 ? (
        <Row className="g-4">
          {filteredCars.map(car => (
            <Col key={car.id} md={4} sm={6} className="mb-4">
              <CarCard {...car} />
            </Col>
          ))}
        </Row>
      ) : (
        <Alert variant="info">
          No cars match your current filters. Try adjusting your search criteria.
        </Alert>
      )}
    </Container>
  );
};

export default CarListing;
import React, { useState, useContext } from 'react';
import { Container, Row, Col, Form, Button, Card, Alert } from 'react-bootstrap';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import { UserContext } from '../contexts/UserContext';
import { loginUser } from '../services/api';

interface LocationState {
  redirect?: string;
}

const LoginPage: React.FC = () => {
  const { login } = useContext(UserContext);
  const navigate = useNavigate();
  const location = useLocation();
  const { redirect } = (location.state as LocationState) || { redirect: '/' };
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      const response = await loginUser({ email, password });
      
      if (response.user) {
        login(response.user);
        navigate(redirect);
      } else {
        setError('Invalid login credentials.');
      }
    } catch (err) {
      setError('Login failed. Please check your credentials and try again.');
      console.error('Login error:', err);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Container className="py-5 fade-in">
      <Row className="justify-content-center">
        <Col md={6} lg={5}>
          <Card className="border-0 shadow-sm">
            <Card.Body className="p-4">
              <div className="text-center mb-4">
                <h2>Welcome Back</h2>
                <p className="text-muted">Sign in to your account</p>
              </div>
              
              {error && (
                <Alert variant="danger">{error}</Alert>
              )}
              
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <Mail size={18} />
                    </span>
                    <Form.Control
                      type="email"
                      placeholder="Your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </Form.Group>
                
                <Form.Group className="mb-4">
                  <Form.Label>Password</Form.Label>
                  <div className="input-group">
                    <span className="input-group-text">
                      <Lock size={18} />
                    </span>
                    <Form.Control
                      type="password"
                      placeholder="Your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </Form.Group>
                
                <div className="d-grid mb-3">
                  <Button 
                    type="submit" 
                    variant="primary" 
                    size="lg"
                    disabled={loading}
                  >
                    {loading ? 'Signing in...' : 'Sign In'}
                  </Button>
                </div>
                
                <div className="text-center">
                  <p className="mb-0">
                    Don't have an account? 
                    <Link to="/register" className="ms-1 text-decoration-none">
                      Create one
                      <ArrowRight size={16} className="ms-1" />
                    </Link>
                  </p>
                </div>
              </Form>
            </Card.Body>
          </Card>
          
          <div className="mt-4 text-center text-muted">
            <small>
              For demo purposes, you can use:<br />
              Admin: <code>admin@example.com / admin123</code><br />
              Customer: <code>john@example.com / password123</code>
            </small>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default LoginPage;
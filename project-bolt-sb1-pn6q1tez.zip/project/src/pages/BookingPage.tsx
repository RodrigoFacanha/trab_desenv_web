import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Container, Row, Col, Form, Button, 
  Card, Alert, ListGroup
} from 'react-bootstrap';
import { 
  Calendar, CreditCard, CheckSquare, 
  AlertTriangle, DollarSign
} from 'lucide-react';
import { UserContext } from '../contexts/UserContext';
import { fetchCarById, createBooking } from '../services/api';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
}

const BookingPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  
  const [car, setCar] = useState<Car | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  
  // Form state
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [totalDays, setTotalDays] = useState(1);
  const [totalPrice, setTotalPrice] = useState(0);
  const [formErrors, setFormErrors] = useState({
    dates: false
  });
  
  // Calculate today and tomorrow for min dates
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  
  useEffect(() => {
    // Redirect if user is not logged in
    if (!user) {
      navigate('/login', { state: { redirect: `/booking/${id}` } });
      return;
    }
    
    const loadCar = async () => {
      try {
        setLoading(true);
        const carId = parseInt(id || '0');
        const carData = await fetchCarById(carId);
        setCar(carData);
        
        // Initialize with tomorrow as start date and day after as end date
        const tomorrowDate = new Date(Date.now() + 86400000);
        const dayAfterTomorrow = new Date(Date.now() + 2 * 86400000);
        
        setStartDate(tomorrowDate.toISOString().split('T')[0]);
        setEndDate(dayAfterTomorrow.toISOString().split('T')[0]);
        
        // Initialize price
        setTotalPrice(carData.price);
        
        setError(null);
      } catch (err) {
        setError('Failed to load car details. Please try again later.');
        console.error('Error fetching car:', err);
      } finally {
        setLoading(false);
      }
    };
    
    if (id) {
      loadCar();
    }
  }, [id, user, navigate]);
  
  useEffect(() => {
    // Calculate total days and price when dates change
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Calculate difference in days
      const diffTime = end.getTime() - start.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays < 1) {
        setFormErrors(prev => ({ ...prev, dates: true }));
        setTotalDays(1);
        setTotalPrice(car?.price || 0);
      } else {
        setFormErrors(prev => ({ ...prev, dates: false }));
        setTotalDays(diffDays);
        setTotalPrice((car?.price || 0) * diffDays);
      }
    }
  }, [startDate, endDate, car]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (formErrors.dates || !startDate || !endDate) {
      setFormErrors(prev => ({ ...prev, dates: true }));
      return;
    }
    
    try {
      if (!car || !user) return;
      
      const bookingData = {
        carId: car.id,
        userId: user.id,
        startDate,
        endDate,
        totalPrice
      };
      
      await createBooking(bookingData);
      setBookingSuccess(true);
      
      // Redirect to bookings page after 2 seconds
      setTimeout(() => {
        navigate('/my-bookings');
      }, 2000);
    } catch (err) {
      setError('Failed to create booking. Please try again.');
      console.error('Error creating booking:', err);
    }
  };
  
  if (loading) {
    return (
      <Container className="py-5 text-center">
        <div>Loading booking information...</div>
      </Container>
    );
  }
  
  if (error) {
    return (
      <Container className="py-5">
        <Alert variant="danger">{error}</Alert>
      </Container>
    );
  }
  
  if (bookingSuccess) {
    return (
      <Container className="py-5 text-center fade-in">
        <Alert variant="success" className="d-flex align-items-center">
          <CheckSquare size={24} className="me-2" />
          <div>
            <h4 className="alert-heading mb-1">Booking Confirmed!</h4>
            <p className="mb-0">Your booking has been successfully processed. Redirecting to your bookings...</p>
          </div>
        </Alert>
      </Container>
    );
  }
  
  if (!car) {
    return (
      <Container className="py-5">
        <Alert variant="danger">Car not found. Please try another vehicle.</Alert>
      </Container>
    );
  }
  
  return (
    <Container className="py-5 fade-in">
      <h1 className="mb-4">Complete Your Booking</h1>
      
      <Row>
        <Col md={8}>
          <Card className="border-0 shadow-sm mb-4">
            <Card.Body>
              <h4 className="mb-4">Booking Details</h4>
              
              <Form onSubmit={handleSubmit}>
                <Row className="mb-4">
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Pickup Date</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Calendar size={18} />
                        </span>
                        <Form.Control
                          type="date"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                          min={today}
                          required
                          isInvalid={formErrors.dates}
                        />
                      </div>
                    </Form.Group>
                  </Col>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Return Date</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <Calendar size={18} />
                        </span>
                        <Form.Control
                          type="date"
                          value={endDate}
                          onChange={(e) => setEndDate(e.target.value)}
                          min={startDate || tomorrow}
                          required
                          isInvalid={formErrors.dates}
                        />
                      </div>
                      {formErrors.dates && (
                        <Form.Text className="text-danger">
                          Please select valid dates (return date must be after pickup date).
                        </Form.Text>
                      )}
                    </Form.Group>
                  </Col>
                </Row>
                
                <h4 className="mb-3">Payment Information</h4>
                
                <Row className="mb-3">
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Card Number</Form.Label>
                      <div className="input-group">
                        <span className="input-group-text">
                          <CreditCard size={18} />
                        </span>
                        <Form.Control
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          required
                        />
                      </div>
                    </Form.Group>
                  </Col>
                  
                  <Col md={3}>
                    <Form.Group className="mb-3">
                      <Form.Label>Expiry Date</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="MM/YY"
                        required
                      />
                    </Form.Group>
                  </Col>
                  
                  <Col md={3}>
                    <Form.Group className="mb-3">
                      <Form.Label>CVV</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="123"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Row>
                  <Col md={12}>
                    <Form.Group className="mb-3">
                      <Form.Label>Cardholder Name</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="John Doe"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <Alert variant="info" className="d-flex align-items-start mt-4">
                  <AlertTriangle size={18} className="me-2 mt-1 flex-shrink-0" />
                  <small>
                    This is a demo application. No actual payment will be processed.
                    For testing purposes, you can enter any values in the payment form.
                  </small>
                </Alert>
                
                <div className="d-grid mt-4">
                  <Button 
                    type="submit" 
                    variant="primary" 
                    size="lg"
                    className="d-flex align-items-center justify-content-center"
                  >
                    <CheckSquare size={18} className="me-2" />
                    Confirm Booking
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
        </Col>
        
        <Col md={4}>
          <Card className="sticky-top border-0 shadow-sm" style={{ top: '20px' }}>
            <Card.Body>
              <h4 className="mb-3">Booking Summary</h4>
              
              <div className="d-flex align-items-center mb-3">
                <img 
                  src={car.images[0]} 
                  alt={`${car.brand} ${car.model}`} 
                  className="rounded"
                  style={{ width: '80px', height: '60px', objectFit: 'cover' }}
                />
                <div className="ms-3">
                  <h5 className="mb-0">{car.brand} {car.model}</h5>
                  <span className="text-muted">{car.year} • {car.type}</span>
                </div>
              </div>
              
              <ListGroup variant="flush" className="mb-3">
                <ListGroup.Item className="px-0 d-flex justify-content-between">
                  <span>Daily Rate:</span>
                  <span>${car.price}/day</span>
                </ListGroup.Item>
                <ListGroup.Item className="px-0 d-flex justify-content-between">
                  <span>Duration:</span>
                  <span>{totalDays} day{totalDays !== 1 ? 's' : ''}</span>
                </ListGroup.Item>
                <ListGroup.Item className="px-0 d-flex justify-content-between">
                  <span>Subtotal:</span>
                  <span>${car.price * totalDays}</span>
                </ListGroup.Item>
                <ListGroup.Item className="px-0 d-flex justify-content-between">
                  <span>Insurance:</span>
                  <span>Included</span>
                </ListGroup.Item>
              </ListGroup>
              
              <div className="d-flex justify-content-between align-items-center border-top pt-3">
                <h5 className="mb-0">Total</h5>
                <div className="d-flex align-items-center">
                  <DollarSign size={20} className="text-success" />
                  <span className="fs-4 fw-bold">${totalPrice}</span>
                </div>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default BookingPage;
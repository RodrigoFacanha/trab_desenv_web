import React, { useState, useEffect, useContext } from 'react';
import { Container, Row, Col, Card, Badge, Button, Alert } from 'react-bootstrap';
import { Calendar, Clock, Ban, CheckSquare } from 'lucide-react';
import { UserContext } from '../contexts/UserContext';
import { fetchUserBookings, cancelBooking, fetchCarById } from '../services/api';
import { useNavigate } from 'react-router-dom';

interface Car {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
}

interface Booking {
  id: number;
  carId: number;
  userId: number;
  startDate: string;
  endDate: string;
  totalPrice: number;
  status: string;
  createdAt: string;
  car?: Car;
}

const UserBookings: React.FC = () => {
  const { user } = useContext(UserContext);
  const navigate = useNavigate();
  
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cancelSuccess, setCancelSuccess] = useState<number | null>(null);
  
  useEffect(() => {
    // Redirect if user is not logged in
    if (!user) {
      navigate('/login');
      return;
    }
    
    const loadBookings = async () => {
      try {
        setLoading(true);
        const bookingsData = await fetchUserBookings(user.id);
        
        // Load car details for each booking
        const bookingsWithCars = await Promise.all(
          bookingsData.map(async (booking: Booking) => {
            try {
              const car = await fetchCarById(booking.carId);
              return { ...booking, car };
            } catch (err) {
              console.error(`Error fetching car ${booking.carId}:`, err);
              return booking;
            }
          })
        );
        
        setBookings(bookingsWithCars);
        setError(null);
      } catch (err) {
        setError('Failed to load your bookings. Please try again later.');
        console.error('Error fetching bookings:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadBookings();
  }, [user, navigate]);
  
  const handleCancelBooking = async (bookingId: number) => {
    try {
      await cancelBooking(bookingId);
      setCancelSuccess(bookingId);
      
      // Update bookings list
      setBookings(prev => 
        prev.filter(booking => booking.id !== bookingId)
      );
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setCancelSuccess(null);
      }, 3000);
    } catch (err) {
      setError('Failed to cancel booking. Please try again.');
      console.error('Error cancelling booking:', err);
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  if (loading) {
    return (
      <Container className="py-5 text-center">
        <div>Loading your bookings...</div>
      </Container>
    );
  }
  
  return (
    <Container className="py-5 fade-in">
      <h1 className="mb-4">My Bookings</h1>
      
      {error && (
        <Alert variant="danger" className="mb-4">{error}</Alert>
      )}
      
      {cancelSuccess && (
        <Alert variant="success" className="mb-4 d-flex align-items-center">
          <CheckSquare size={20} className="me-2" />
          Booking cancelled successfully.
        </Alert>
      )}
      
      {bookings.length === 0 ? (
        <Card className="border-0 shadow-sm">
          <Card.Body className="text-center py-5">
            <h4 className="mb-3">No bookings found</h4>
            <p className="text-muted mb-4">You haven't made any car reservations yet.</p>
            <Button 
              variant="primary"
              onClick={() => navigate('/cars')}
            >
              Browse Cars
            </Button>
          </Card.Body>
        </Card>
      ) : (
        <Row className="g-4">
          {bookings.map(booking => (
            <Col key={booking.id} md={6}>
              <Card className="border-0 shadow-sm h-100">
                <Row className="g-0">
                  <Col xs={4}>
                    <img 
                      src={booking.car?.images[0] || 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg'} 
                      alt={booking.car?.brand || 'Car'} 
                      className="img-fluid rounded-start h-100"
                      style={{ objectFit: 'cover' }}
                    />
                  </Col>
                  <Col xs={8}>
                    <Card.Body>
                      <div className="d-flex justify-content-between align-items-start mb-2">
                        <h5 className="card-title mb-0">
                          {booking.car?.brand} {booking.car?.model}
                        </h5>
                        <Badge bg="success" className="ms-2 px-2">
                          Confirmed
                        </Badge>
                      </div>
                      
                      <div className="mb-3 text-muted small">
                        {booking.car?.year} • {booking.car?.type}
                      </div>
                      
                      <div className="mb-2 d-flex align-items-center">
                        <Calendar size={16} className="text-primary me-2" />
                        <span>
                          {formatDate(booking.startDate)} - {formatDate(booking.endDate)}
                        </span>
                      </div>
                      
                      <div className="mb-3 d-flex align-items-center">
                        <Clock size={16} className="text-primary me-2" />
                        <span className="text-muted small">
                          Booked on {formatDate(booking.createdAt)}
                        </span>
                      </div>
                      
                      <div className="d-flex justify-content-between align-items-center mt-auto">
                        <div className="fw-bold">
                          Total: ${booking.totalPrice}
                        </div>
                        
                        <Button 
                          variant="outline-danger" 
                          size="sm"
                          className="d-flex align-items-center"
                          onClick={() => handleCancelBooking(booking.id)}
                        >
                          <Ban size={16} className="me-1" />
                          Cancel
                        </Button>
                      </div>
                    </Card.Body>
                  </Col>
                </Row>
              </Card>
            </Col>
          ))}
        </Row>
      )}
    </Container>
  );
};

export default UserBookings;
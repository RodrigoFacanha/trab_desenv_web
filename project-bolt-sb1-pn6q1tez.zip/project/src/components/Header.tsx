import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Navbar, Nav, Container, Button, Dropdown } from 'react-bootstrap';
import { Car, User, Menu } from 'lucide-react';
import { UserContext } from '../contexts/UserContext';

const Header: React.FC = () => {
  const { user, logout } = useContext(UserContext);
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState(false);

  const handleLogout = () => {
    logout();
    setExpanded(false);
  };

  const handleNavigation = (path: string) => {
    navigate(path);
    setExpanded(false);
  };

  return (
    <Navbar bg="white" expand="lg" sticky="top" expanded={expanded} onToggle={setExpanded}>
      <Container>
        <Navbar.Brand as={Link} to="/" className="d-flex align-items-center">
          <Car className="me-2" size={24} strokeWidth={2} />
          <span className="fw-bold">Drive Elite</span>
        </Navbar.Brand>
        
        <Navbar.Toggle aria-controls="basic-navbar-nav">
          <Menu size={24} />
        </Navbar.Toggle>
        
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/" onClick={() => setExpanded(false)}>Home</Nav.Link>
            <Nav.Link as={Link} to="/cars" onClick={() => setExpanded(false)}>Browse Cars</Nav.Link>
          </Nav>
          
          <Nav>
            {user ? (
              <Dropdown align="end">
                <Dropdown.Toggle variant="light" id="user-dropdown" className="border">
                  <User size={18} className="me-2" />
                  {user.name}
                </Dropdown.Toggle>
                <Dropdown.Menu>
                  {user.role === 'admin' && (
                    <Dropdown.Item onClick={() => handleNavigation('/admin')}>
                      Admin Dashboard
                    </Dropdown.Item>
                  )}
                  <Dropdown.Item onClick={() => handleNavigation('/my-bookings')}>
                    My Bookings
                  </Dropdown.Item>
                  <Dropdown.Divider />
                  <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            ) : (
              <div className="d-flex">
                <Button 
                  variant="outline-primary" 
                  className="me-2"
                  onClick={() => handleNavigation('/login')}
                >
                  Login
                </Button>
                <Button 
                  variant="primary"
                  onClick={() => handleNavigation('/register')}
                >
                  Register
                </Button>
              </div>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
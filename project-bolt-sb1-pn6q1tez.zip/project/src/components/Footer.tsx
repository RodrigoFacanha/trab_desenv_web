import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="mt-auto">
      <Container>
        <Row className="py-4">
          <Col md={4} className="mb-4 mb-md-0">
            <h5 className="mb-3 text-white">Drive Elite</h5>
            <p className="text-light">
              Premium car rental service offering a wide range of vehicles for all your needs.
              Experience the luxury and convenience of our service.
            </p>
            <div className="d-flex mt-3">
              <a href="#" className="text-white me-3"><Facebook size={20} /></a>
              <a href="#" className="text-white me-3"><Twitter size={20} /></a>
              <a href="#" className="text-white me-3"><Instagram size={20} /></a>
              <a href="#" className="text-white"><Youtube size={20} /></a>
            </div>
          </Col>
          
          <Col md={4} className="mb-4 mb-md-0">
            <h5 className="mb-3 text-white">Quick Links</h5>
            <ul className="list-unstyled">
              <li className="mb-2"><a href="/" className="text-light text-decoration-none">Home</a></li>
              <li className="mb-2"><a href="/cars" className="text-light text-decoration-none">Browse Cars</a></li>
              <li className="mb-2"><a href="/login" className="text-light text-decoration-none">Login</a></li>
              <li className="mb-2"><a href="/register" className="text-light text-decoration-none">Register</a></li>
            </ul>
          </Col>
          
          <Col md={4}>
            <h5 className="mb-3 text-white">Contact Us</h5>
            <ul className="list-unstyled">
              <li className="mb-2 text-light">
                <MapPin size={18} className="me-2" />
                123 Rental Street, Car City
              </li>
              <li className="mb-2 text-light">
                <Phone size={18} className="me-2" />
                +1 (555) 123-4567
              </li>
              <li className="mb-2 text-light">
                <Mail size={18} className="me-2" />
                info@driveelite.com
              </li>
            </ul>
          </Col>
        </Row>
        
        <hr className="border-light" />
        
        <div className="text-center py-3 text-light">
          <small>&copy; {currentYear} Drive Elite. All rights reserved.</small>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;
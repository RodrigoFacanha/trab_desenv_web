import React from 'react';
import { Card, Badge, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { Car as CarIcon, DollarSign } from 'lucide-react';

interface CarProps {
  id: number;
  brand: string;
  model: string;
  year: number;
  type: string;
  price: number;
  images: string[];
  available: boolean;
}

const CarCard: React.FC<CarProps> = ({ 
  id, brand, model, year, type, price, images, available 
}) => {
  const navigate = useNavigate();
  
  return (
    <Card className="h-100 car-card border-0 shadow-sm">
      <div className="position-relative">
        <Card.Img 
          variant="top" 
          src={images[0]} 
          alt={`${brand} ${model}`} 
          style={{ height: '200px', objectFit: 'cover' }} 
        />
        {!available && (
          <div className="position-absolute top-0 end-0 bg-danger text-white px-2 py-1 m-2 rounded">
            Unavailable
          </div>
        )}
      </div>
      
      <Card.Body className="d-flex flex-column">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h5 className="card-title mb-0">{brand} {model}</h5>
          <Badge bg="light" text="dark" className="text-muted">{year}</Badge>
        </div>
        
        <div className="mb-3 d-flex align-items-center">
          <CarIcon size={16} className="text-secondary me-2" />
          <span className="text-secondary">{type}</span>
        </div>
        
        <div className="d-flex justify-content-between align-items-center mt-auto">
          <div className="d-flex align-items-center">
            <DollarSign size={18} className="text-primary" />
            <span className="fw-bold">${price}</span>
            <span className="text-muted">/day</span>
          </div>
          
          <Button 
            variant={available ? "primary" : "secondary"}
            disabled={!available}
            onClick={() => navigate(`/cars/${id}`)}
            size="sm"
          >
            {available ? 'View Details' : 'Not Available'}
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default CarCard;
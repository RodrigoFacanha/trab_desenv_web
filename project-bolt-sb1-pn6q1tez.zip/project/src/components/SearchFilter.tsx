import React, { useState } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';
import { Search, X } from 'lucide-react';

interface FilterProps {
  onFilter: (filters: FilterValues) => void;
}

interface FilterValues {
  search: string;
  type: string;
  priceRange: number;
  sortBy: string;
}

const SearchFilter: React.FC<FilterProps> = ({ onFilter }) => {
  const [filters, setFilters] = useState<FilterValues>({
    search: '',
    type: '',
    priceRange: 300,
    sortBy: 'default'
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilter(filters);
  };
  
  const handleReset = () => {
    setFilters({
      search: '',
      type: '',
      priceRange: 300,
      sortBy: 'default'
    });
    onFilter({
      search: '',
      type: '',
      priceRange: 300,
      sortBy: 'default'
    });
  };
  
  return (
    <Form onSubmit={handleSubmit} className="bg-white p-3 rounded shadow-sm mb-4">
      <Row className="g-2">
        <Col md={4}>
          <Form.Group>
            <Form.Control
              type="text"
              placeholder="Search by brand or model"
              name="search"
              value={filters.search}
              onChange={handleChange}
            />
          </Form.Group>
        </Col>
        
        <Col md={2}>
          <Form.Group>
            <Form.Select
              name="type"
              value={filters.type}
              onChange={handleChange}
            >
              <option value="">All Types</option>
              <option value="Sedan">Sedan</option>
              <option value="SUV">SUV</option>
              <option value="Luxury">Luxury</option>
              <option value="Sports">Sports</option>
              <option value="Truck">Truck</option>
            </Form.Select>
          </Form.Group>
        </Col>
        
        <Col md={2}>
          <Form.Group>
            <Form.Label className="small mb-0">Max Price: ${filters.priceRange}</Form.Label>
            <Form.Range
              name="priceRange"
              min={50}
              max={300}
              step={10}
              value={filters.priceRange}
              onChange={handleChange}
            />
          </Form.Group>
        </Col>
        
        <Col md={2}>
          <Form.Group>
            <Form.Select
              name="sortBy"
              value={filters.sortBy}
              onChange={handleChange}
            >
              <option value="default">Sort By</option>
              <option value="priceLow">Price: Low to High</option>
              <option value="priceHigh">Price: High to Low</option>
              <option value="newest">Newest First</option>
            </Form.Select>
          </Form.Group>
        </Col>
        
        <Col md={2} className="d-flex gap-2">
          <Button type="submit" variant="primary" className="w-100 d-flex align-items-center justify-content-center">
            <Search size={18} className="me-1" />
            <span>Filter</span>
          </Button>
          <Button 
            type="button" 
            variant="outline-secondary" 
            onClick={handleReset} 
            className="d-flex align-items-center justify-content-center"
          >
            <X size={18} />
          </Button>
        </Col>
      </Row>
    </Form>
  );
};

export default SearchFilter;
import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

interface HeroProps {
  title: string;
  subtitle: string;
  buttonText?: string;
  buttonLink?: string;
}

const HeroSection: React.FC<HeroProps> = ({ 
  title, 
  subtitle, 
  buttonText = "Browse Cars", 
  buttonLink = "/cars" 
}) => {
  const navigate = useNavigate();
  
  return (
    <div className="hero-section">
      <Container className="hero-content">
        <h1 className="hero-title slide-up">{title}</h1>
        <p className="hero-subtitle slide-up">{subtitle}</p>
        {buttonText && (
          <Button 
            variant="accent" 
            size="lg" 
            className="slide-up"
            onClick={() => navigate(buttonLink)}
          >
            {buttonText}
            <ArrowRight size={18} className="ms-2" />
          </Button>
        )}
      </Container>
    </div>
  );
};

export default HeroSection;
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

app.use(express.json());

// Enable CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Data paths
const dataPath = path.join(__dirname, 'data');
const carsFile = path.join(dataPath, 'cars.json');
const usersFile = path.join(dataPath, 'users.json');
const bookingsFile = path.join(dataPath, 'bookings.json');

// Ensure data directory exists
if (!fs.existsSync(dataPath)) {
  fs.mkdirSync(dataPath, { recursive: true });
}

// Initialize JSON files if they don't exist
if (!fs.existsSync(carsFile)) {
  fs.writeFileSync(carsFile, JSON.stringify({
    cars: [
      {
        id: 1,
        brand: 'Toyota',
        model: 'Camry',
        year: 2023,
        type: 'Sedan',
        price: 65,
        images: ['https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg'],
        available: true,
        features: ['GPS', 'Bluetooth', 'Backup Camera', 'Cruise Control'],
        description: 'Reliable and comfortable sedan, perfect for city driving.'
      },
      {
        id: 2,
        brand: 'Honda',
        model: 'CR-V',
        year: 2022,
        type: 'SUV',
        price: 85,
        images: ['https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg'],
        available: true,
        features: ['All-Wheel Drive', 'Bluetooth', 'Backup Camera', 'Heated Seats'],
        description: 'Compact SUV with ample space and great fuel efficiency.'
      },
      {
        id: 3,
        brand: 'BMW',
        model: '3 Series',
        year: 2023,
        type: 'Luxury',
        price: 120,
        images: ['https://images.pexels.com/photos/3764984/pexels-photo-3764984.jpeg'],
        available: true,
        features: ['Leather Seats', 'Premium Sound System', 'Parking Assist', 'Navigation'],
        description: 'Executive sedan with premium features and excellent performance.'
      },
      {
        id: 4,
        brand: 'Ford',
        model: 'F-150',
        year: 2022,
        type: 'Truck',
        price: 110,
        images: ['https://images.pexels.com/photos/2676096/pexels-photo-2676096.jpeg'],
        available: true,
        features: ['Towing Package', '4x4', 'Bluetooth', 'Backup Camera'],
        description: 'Powerful and versatile pickup truck, ideal for heavy-duty tasks.'
      },
      {
        id: 5,
        brand: 'Chevrolet',
        model: 'Corvette',
        year: 2023,
        type: 'Sports',
        price: 200,
        images: ['https://images.pexels.com/photos/337909/pexels-photo-337909.jpeg'],
        available: true,
        features: ['Leather Seats', 'Premium Sound System', 'Navigation', 'Sports Mode'],
        description: 'Iconic American sports car with breathtaking performance.'
      }
    ]
  }, null, 2));
}

if (!fs.existsSync(usersFile)) {
  fs.writeFileSync(usersFile, JSON.stringify({
    users: [
      {
        id: 1,
        name: 'Admin User',
        email: 'admin@example.com',
        password: 'admin123',
        role: 'admin'
      },
      {
        id: 2,
        name: 'John Doe',
        email: 'john@example.com',
        password: 'password123',
        role: 'customer'
      }
    ]
  }, null, 2));
}

if (!fs.existsSync(bookingsFile)) {
  fs.writeFileSync(bookingsFile, JSON.stringify({
    bookings: []
  }, null, 2));
}

// Helper functions to read and write data
const readData = (file) => {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const writeData = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// API Routes
// Cars
app.get('/api/cars', (req, res) => {
  const data = readData(carsFile);
  res.json(data.cars);
});

app.get('/api/cars/:id', (req, res) => {
  const data = readData(carsFile);
  const car = data.cars.find(c => c.id === parseInt(req.params.id));
  
  if (!car) {
    return res.status(404).json({ message: 'Car not found' });
  }
  
  res.json(car);
});

app.post('/api/cars', (req, res) => {
  const data = readData(carsFile);
  const newCar = {
    id: data.cars.length ? Math.max(...data.cars.map(c => c.id)) + 1 : 1,
    ...req.body,
    available: true
  };
  
  data.cars.push(newCar);
  writeData(carsFile, data);
  
  res.status(201).json(newCar);
});

app.put('/api/cars/:id', (req, res) => {
  const data = readData(carsFile);
  const carIndex = data.cars.findIndex(c => c.id === parseInt(req.params.id));
  
  if (carIndex === -1) {
    return res.status(404).json({ message: 'Car not found' });
  }
  
  data.cars[carIndex] = { ...data.cars[carIndex], ...req.body };
  writeData(carsFile, data);
  
  res.json(data.cars[carIndex]);
});

app.delete('/api/cars/:id', (req, res) => {
  const data = readData(carsFile);
  const carIndex = data.cars.findIndex(c => c.id === parseInt(req.params.id));
  
  if (carIndex === -1) {
    return res.status(404).json({ message: 'Car not found' });
  }
  
  data.cars.splice(carIndex, 1);
  writeData(carsFile, data);
  
  res.json({ message: 'Car deleted successfully' });
});

// Users & Authentication
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const data = readData(usersFile);
  const user = data.users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  
  // In a real app, you'd use JWT or another token method
  const { password: _, ...userWithoutPassword } = user;
  res.json({ user: userWithoutPassword });
});

app.post('/api/auth/register', (req, res) => {
  const data = readData(usersFile);
  const { email } = req.body;
  
  if (data.users.some(u => u.email === email)) {
    return res.status(400).json({ message: 'User already exists' });
  }
  
  const newUser = {
    id: data.users.length ? Math.max(...data.users.map(u => u.id)) + 1 : 1,
    ...req.body,
    role: 'customer'
  };
  
  data.users.push(newUser);
  writeData(usersFile, data);
  
  const { password: _, ...userWithoutPassword } = newUser;
  res.status(201).json({ user: userWithoutPassword });
});

// Bookings
app.get('/api/bookings', (req, res) => {
  const data = readData(bookingsFile);
  res.json(data.bookings);
});

app.get('/api/bookings/user/:userId', (req, res) => {
  const data = readData(bookingsFile);
  const userBookings = data.bookings.filter(b => b.userId === parseInt(req.params.userId));
  res.json(userBookings);
});

app.post('/api/bookings', (req, res) => {
  const bookingsData = readData(bookingsFile);
  const carsData = readData(carsFile);
  
  const { carId, startDate, endDate, userId } = req.body;
  
  // Check if car exists and is available
  const carIndex = carsData.cars.findIndex(c => c.id === carId);
  if (carIndex === -1) {
    return res.status(404).json({ message: 'Car not found' });
  }
  
  const newBooking = {
    id: bookingsData.bookings.length ? Math.max(...bookingsData.bookings.map(b => b.id)) + 1 : 1,
    carId,
    userId,
    startDate,
    endDate,
    totalPrice: carsData.cars[carIndex].price * ((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)),
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  
  bookingsData.bookings.push(newBooking);
  writeData(bookingsFile, bookingsData);
  
  // Update car availability
  carsData.cars[carIndex].available = false;
  writeData(carsFile, carsData);
  
  res.status(201).json(newBooking);
});

app.put('/api/bookings/:id', (req, res) => {
  const bookingsData = readData(bookingsFile);
  const bookingIndex = bookingsData.bookings.findIndex(b => b.id === parseInt(req.params.id));
  
  if (bookingIndex === -1) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  
  bookingsData.bookings[bookingIndex] = { ...bookingsData.bookings[bookingIndex], ...req.body };
  writeData(bookingsFile, bookingsData);
  
  res.json(bookingsData.bookings[bookingIndex]);
});

app.delete('/api/bookings/:id', (req, res) => {
  const bookingsData = readData(bookingsFile);
  const carsData = readData(carsFile);
  
  const bookingIndex = bookingsData.bookings.findIndex(b => b.id === parseInt(req.params.id));
  
  if (bookingIndex === -1) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  
  const booking = bookingsData.bookings[bookingIndex];
  
  // Make car available again
  const carIndex = carsData.cars.findIndex(c => c.id === booking.carId);
  if (carIndex !== -1) {
    carsData.cars[carIndex].available = true;
    writeData(carsFile, carsData);
  }
  
  bookingsData.bookings.splice(bookingIndex, 1);
  writeData(bookingsFile, bookingsData);
  
  res.json({ message: 'Booking cancelled successfully' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
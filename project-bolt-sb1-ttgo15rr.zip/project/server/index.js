import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import bodyParser from 'body-parser';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Initialize Express
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'dist' directory after build or from root during development
app.use(express.static(join(__dirname, '../dist')));
app.use(express.static(join(__dirname, '..')));

// In-memory data store for MVP
const cars = [
  {
    id: '1',
    make: 'Toyota',
    model: 'Corolla',
    year: 2022,
    type: 'economy',
    dailyRate: 45,
    image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
    capacity: 5,
    transmission: 'automatic',
    fuel: 'gasoline',
    featured: true,
    description: 'The Toyota Corolla is a reliable and fuel-efficient compact car, perfect for city driving and short trips.',
    features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera']
  },
  {
    id: '2',
    make: 'Honda',
    model: 'Civic',
    year: 2023,
    type: 'compact',
    dailyRate: 50,
    image: 'https://images.pexels.com/photos/1009871/pexels-photo-1009871.jpeg',
    capacity: 5,
    transmission: 'automatic',
    fuel: 'gasoline',
    featured: true,
    description: 'The Honda Civic offers excellent fuel economy, a comfortable interior, and responsive handling for an enjoyable driving experience.',
    features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation']
  },
  {
    id: '3',
    make: 'Ford',
    model: 'Explorer',
    year: 2022,
    type: 'suv',
    dailyRate: 85,
    image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
    capacity: 7,
    transmission: 'automatic',
    fuel: 'gasoline',
    featured: true,
    description: 'The Ford Explorer is a spacious three-row SUV with plenty of cargo space, making it ideal for family trips and adventures.',
    features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Sunroof']
  },
  {
    id: '4',
    make: 'Mercedes-Benz',
    model: 'E-Class',
    year: 2023,
    type: 'luxury',
    dailyRate: 120,
    image: 'https://images.pexels.com/photos/120049/pexels-photo-120049.jpeg',
    capacity: 5,
    transmission: 'automatic',
    fuel: 'gasoline',
    featured: true,
    description: 'The Mercedes-Benz E-Class combines luxury, performance, and cutting-edge technology for a premium driving experience.',
    features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Leather Seats', 'Sunroof']
  }
];

const bookings = [];
const users = [];

// API Routes

// Get all cars
app.get('/api/cars', (req, res) => {
  res.json(cars);
});

// Get car by ID
app.get('/api/cars/:id', (req, res) => {
  const car = cars.find(car => car.id === req.params.id);
  if (!car) {
    return res.status(404).json({ message: 'Car not found' });
  }
  res.json(car);
});

// Create a new booking
app.post('/api/bookings', (req, res) => {
  const { carId, pickupDate, returnDate, pickupLocation, returnLocation, customer } = req.body;
  
  // Check if car exists
  const car = cars.find(car => car.id === carId);
  if (!car) {
    return res.status(404).json({ message: 'Car not found' });
  }
  
  // Generate booking ID
  const bookingId = 'BK' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
  
  // Calculate number of days
  const start = new Date(pickupDate);
  const end = new Date(returnDate);
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // Minimum 1 day
  
  // Calculate total price
  const basePrice = car.dailyRate * diffDays;
  const tax = basePrice * 0.08; // 8% tax
  const total = basePrice + tax;
  
  // Create booking
  const newBooking = {
    id: bookingId,
    carId,
    car: {
      make: car.make,
      model: car.model,
      year: car.year,
      dailyRate: car.dailyRate
    },
    pickupDate,
    returnDate,
    pickupLocation,
    returnLocation,
    customer,
    days: diffDays,
    total,
    status: 'confirmed',
    createdAt: new Date().toISOString()
  };
  
  // Save booking
  bookings.push(newBooking);
  
  res.status(201).json(newBooking);
});

// Get all bookings
app.get('/api/bookings', (req, res) => {
  res.json(bookings);
});

// Get booking by ID
app.get('/api/bookings/:id', (req, res) => {
  const booking = bookings.find(booking => booking.id === req.params.id);
  if (!booking) {
    return res.status(404).json({ message: 'Booking not found' });
  }
  res.json(booking);
});

// Register user
app.post('/api/auth/register', (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  
  // Check if user already exists
  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    return res.status(400).json({ message: 'User already exists' });
  }
  
  // Create user
  const newUser = {
    id: 'user' + Math.floor(Math.random() * 1000),
    firstName,
    lastName,
    email,
    password, // In a real app, this would be hashed
    registeredDate: new Date().toISOString()
  };
  
  // Save user
  users.push(newUser);
  
  // Return user data (without password)
  const { password: _, ...userData } = newUser;
  res.status(201).json(userData);
});

// Login user
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  // Find user
  const user = users.find(user => user.email === email && user.password === password);
  if (!user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  
  // Return user data (without password)
  const { password: _, ...userData } = user;
  res.json(userData);
});

// Handle client-side routing - send all requests to index.html
app.get('*', (req, res) => {
  res.sendFile(join(__dirname, '../index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
import { fetchCars, getTypeColor, capitalizeFirstLetter } from './main.js';

// DOM elements
const carListContainer = document.getElementById('car-list-container');
const filterForm = document.getElementById('filter-form');
const sortBySelect = document.getElementById('sort-by');
const resultsCount = document.getElementById('results-count');
const paginationContainer = document.getElementById('pagination-container');

// State
let cars = [];
let filteredCars = [];
let currentPage = 1;
const carsPerPage = 6;
let filters = {
  type: '',
  minPrice: '',
  maxPrice: '',
  features: []
};

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  // Parse URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const locationParam = urlParams.get('location');
  const pickupParam = urlParams.get('pickup');
  const returnParam = urlParams.get('return');

  // Set form values from URL parameters if available
  if (locationParam && document.getElementById('pickup-location')) {
    document.getElementById('pickup-location').value = locationParam;
  }
  
  if (pickupParam && document.getElementById('pickup-date')) {
    document.getElementById('pickup-date').value = pickupParam;
  }
  
  if (returnParam && document.getElementById('return-date')) {
    document.getElementById('return-date').value = returnParam;
  }

  // Load cars data
  await loadCars();

  // Add event listeners
  if (filterForm) {
    filterForm.addEventListener('submit', handleFilterSubmit);
    filterForm.addEventListener('reset', handleFilterReset);
  }

  if (sortBySelect) {
    sortBySelect.addEventListener('change', handleSort);
  }

  // Feature checkboxes
  document.querySelectorAll('.form-check-input[id^="feature-"]').forEach(checkbox => {
    checkbox.addEventListener('change', () => {
      if (filterForm) filterForm.dispatchEvent(new Event('submit'));
    });
  });
});

// Load cars data
async function loadCars() {
  try {
    cars = await fetchCars();
    filteredCars = [...cars];
    
    updateResultsCount();
    renderCars();
    renderPagination();
  } catch (error) {
    console.error('Error loading cars:', error);
    if (carListContainer) {
      carListContainer.innerHTML = `
        <div class="col-12">
          <div class="alert alert-danger" role="alert">
            Error loading cars. Please try again later.
          </div>
        </div>
      `;
    }
  }
}

// Filter form submission
function handleFilterSubmit(e) {
  e.preventDefault();
  
  // Get filter values
  const carType = document.getElementById('car-type').value;
  const minPrice = document.getElementById('min-price').value;
  const maxPrice = document.getElementById('max-price').value;
  
  // Get checked features
  const featureInputs = document.querySelectorAll('.form-check-input[id^="feature-"]:checked');
  const selectedFeatures = Array.from(featureInputs).map(input => {
    const featureName = input.id.replace('feature-', '');
    return featureName;
  });
  
  // Update filters
  filters = {
    type: carType,
    minPrice: minPrice,
    maxPrice: maxPrice,
    features: selectedFeatures
  };
  
  // Apply filters
  applyFilters();
  
  // Reset to first page
  currentPage = 1;
  renderCars();
  renderPagination();
}

// Reset filters
function handleFilterReset() {
  filters = {
    type: '',
    minPrice: '',
    maxPrice: '',
    features: []
  };
  
  setTimeout(() => {
    applyFilters();
    currentPage = 1;
    renderCars();
    renderPagination();
  }, 0);
}

// Apply filters to car list
function applyFilters() {
  filteredCars = cars.filter(car => {
    // Filter by type
    if (filters.type && car.type !== filters.type) {
      return false;
    }
    
    // Filter by price range
    if (filters.minPrice && car.dailyRate < parseFloat(filters.minPrice)) {
      return false;
    }
    
    if (filters.maxPrice && car.dailyRate > parseFloat(filters.maxPrice)) {
      return false;
    }
    
    // Filter by features
    if (filters.features.length > 0) {
      // Convert feature keys to lowercase for comparison
      const carFeaturesLower = car.features.map(feature => feature.toLowerCase());
      
      // Check if car has all selected features
      for (const feature of filters.features) {
        // Convert AC to "air conditioning" for matching
        let featureToCheck = feature === 'ac' ? 'air conditioning' : feature;
        
        if (!carFeaturesLower.some(f => f.toLowerCase().includes(featureToCheck))) {
          return false;
        }
      }
    }
    
    return true;
  });
  
  // Apply sorting
  handleSort();
  
  // Update results count
  updateResultsCount();
}

// Sort car list
function handleSort() {
  const sortValue = sortBySelect ? sortBySelect.value : 'price-asc';
  
  filteredCars.sort((a, b) => {
    switch (sortValue) {
      case 'price-asc':
        return a.dailyRate - b.dailyRate;
      case 'price-desc':
        return b.dailyRate - a.dailyRate;
      case 'name-asc':
        return (a.make + a.model).localeCompare(b.make + b.model);
      case 'name-desc':
        return (b.make + b.model).localeCompare(a.make + a.model);
      default:
        return 0;
    }
  });
  
  renderCars();
}

// Update results count
function updateResultsCount() {
  if (resultsCount) {
    resultsCount.textContent = `Showing ${filteredCars.length} cars`;
  }
}

// Render cars list with pagination
function renderCars() {
  if (!carListContainer) return;
  
  // Calculate pagination
  const startIndex = (currentPage - 1) * carsPerPage;
  const endIndex = startIndex + carsPerPage;
  const paginatedCars = filteredCars.slice(startIndex, endIndex);
  
  if (paginatedCars.length === 0) {
    carListContainer.innerHTML = `
      <div class="col-12">
        <div class="alert alert-info" role="alert">
          No cars match your filters. Try adjusting your search criteria.
        </div>
      </div>
    `;
    return;
  }
  
  let cardsHTML = '';
  paginatedCars.forEach(car => {
    cardsHTML += `
      <div class="col-lg-6 col-xl-4 mb-4">
        <div class="card car-card border-0 shadow-sm h-100">
          <img src="${car.image}" class="card-img-top" alt="${car.make} ${car.model}">
          <div class="card-body">
            <span class="badge bg-${getTypeColor(car.type)} car-type-badge">${capitalizeFirstLetter(car.type)}</span>
            <h5 class="card-title mt-2">${car.make} ${car.model}</h5>
            <p class="text-muted mb-2">${car.year} • ${capitalizeFirstLetter(car.transmission)} • ${capitalizeFirstLetter(car.fuel)}</p>
            <div class="d-flex mb-3">
              <div class="me-3">
                <i class="bi bi-people me-1"></i>
                <span>${car.capacity} Seats</span>
              </div>
              <div>
                <i class="bi bi-speedometer me-1"></i>
                <span>Unlimited Miles</span>
              </div>
            </div>
            <p class="card-text text-truncate mb-3">${car.description}</p>
            <hr>
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <span class="fs-5 fw-bold text-primary">$${car.dailyRate}</span>
                <span class="text-muted">/day</span>
              </div>
              <a href="/pages/car-details.html?id=${car.id}" class="btn btn-primary">View Details</a>
            </div>
          </div>
        </div>
      </div>
    `;
  });
  
  carListContainer.innerHTML = cardsHTML;
}

// Render pagination controls
function renderPagination() {
  if (!paginationContainer) return;
  
  const totalPages = Math.ceil(filteredCars.length / carsPerPage);
  
  if (totalPages <= 1) {
    paginationContainer.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // Previous button
  paginationHTML += `
    <li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
      <a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
  `;
  
  // Page numbers
  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `
      <li class="page-item ${i === currentPage ? 'active' : ''}">
        <a class="page-link" href="#" data-page="${i}">${i}</a>
      </li>
    `;
  }
  
  // Next button
  paginationHTML += `
    <li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
      <a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  `;
  
  paginationContainer.innerHTML = paginationHTML;
  
  // Add event listeners to pagination links
  const pageLinks = paginationContainer.querySelectorAll('.page-link');
  pageLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const pageNum = parseInt(link.dataset.page);
      if (pageNum && pageNum !== currentPage && pageNum > 0 && pageNum <= totalPages) {
        currentPage = pageNum;
        renderCars();
        renderPagination();
        // Scroll to top of results
        carListContainer.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}
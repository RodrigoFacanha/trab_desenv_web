import { checkLoginStatus, isAdmin } from './main.js';

// Redirect to home if not logged in or not admin
if (!checkLoginStatus() || !isAdmin()) {
  window.location.href = '/';
}

// DOM elements
const adminNav = document.getElementById('admin-nav');
const adminLogoutBtn = document.getElementById('admin-logout-btn');
const carsTableBody = document.getElementById('cars-table-body');
const bookingsTableBody = document.getElementById('bookings-table-body');
const usersTableBody = document.getElementById('users-table-body');
const saveCarBtn = document.getElementById('save-car-btn');
const updateCarBtn = document.getElementById('update-car-btn');

// State
let cars = [];
let bookings = [];
let users = [];

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  // Add event listeners for tab navigation
  if (adminNav) {
    const tabLinks = adminNav.querySelectorAll('[data-tab]');
    tabLinks.forEach(link => {
      link.addEventListener('click', handleTabChange);
    });
  }
  
  // Add event listener for logout
  if (adminLogoutBtn) {
    adminLogoutBtn.addEventListener('click', handleLogout);
  }
  
  // Add event listener for adding car
  if (saveCarBtn) {
    saveCarBtn.addEventListener('click', handleAddCar);
  }
  
  // Add event listener for updating car
  if (updateCarBtn) {
    updateCarBtn.addEventListener('click', handleUpdateCar);
  }
  
  // Load dashboard data
  loadDashboardData();
  
  // Check if we have a tab in the URL hash
  const hash = window.location.hash.substring(1);
  if (hash) {
    const tabLink = document.querySelector(`[data-tab="${hash}"]`);
    if (tabLink) {
      tabLink.click();
    }
  }
});

// Handle tab changes
function handleTabChange(e) {
  e.preventDefault();
  
  // Get the target tab
  const tabName = this.dataset.tab;
  
  // Remove active class from all tabs
  const allTabLinks = adminNav.querySelectorAll('[data-tab]');
  allTabLinks.forEach(link => {
    link.classList.remove('active');
  });
  
  // Add active class to clicked tab
  this.classList.add('active');
  
  // Hide all tab content
  const allTabContent = document.querySelectorAll('.tab-content');
  allTabContent.forEach(content => {
    content.classList.add('d-none');
  });
  
  // Show selected tab content
  const targetContent = document.getElementById(`admin-${tabName}-tab`);
  if (targetContent) {
    targetContent.classList.remove('d-none');
  }
  
  // Load data for the selected tab
  switch (tabName) {
    case 'cars':
      loadCarsData();
      break;
    case 'bookings':
      loadBookingsData();
      break;
    case 'users':
      loadUsersData();
      break;
  }
  
  // Update URL hash
  window.location.hash = tabName;
}

// Handle logout
function handleLogout(e) {
  e.preventDefault();
  localStorage.removeItem('user');
  window.location.href = '/';
}

// Load dashboard data
function loadDashboardData() {
  // Get data
  cars = getDummyCars();
  bookings = getDummyBookings();
  users = getDummyUsers();
  
  // Update dashboard counts
  document.getElementById('total-cars-count').textContent = cars.length;
  document.getElementById('available-cars-count').textContent = cars.filter(car => car.status === 'available').length;
  document.getElementById('admin-active-bookings-count').textContent = bookings.filter(booking => booking.status === 'active').length;
  document.getElementById('total-users-count').textContent = users.length;
  
  // Load recent bookings
  loadRecentBookings();
}

// Load recent bookings
function loadRecentBookings() {
  const recentBookingsTable = document.getElementById('recent-bookings');
  if (!recentBookingsTable) return;
  
  // Get 5 most recent bookings
  const recentBookings = [...bookings].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  
  if (recentBookings.length === 0) {
    recentBookingsTable.innerHTML = '<tr><td colspan="5" class="text-center">No bookings found</td></tr>';
    return;
  }
  
  let bookingsHTML = '';
  recentBookings.forEach(booking => {
    const car = cars.find(car => car.id === booking.carId);
    const user = users.find(user => user.id === booking.userId);
    
    bookingsHTML += `
      <tr>
        <td>${booking.id}</td>
        <td>${car ? `${car.make} ${car.model}` : 'Unknown Car'}</td>
        <td>${user ? `${user.firstName} ${user.lastName}` : 'Unknown User'}</td>
        <td>${formatDate(booking.pickupDate)} - ${formatDate(booking.returnDate)}</td>
        <td><span class="badge ${getStatusBadgeClass(booking.status)}">${capitalizeFirstLetter(booking.status)}</span></td>
      </tr>
    `;
  });
  
  recentBookingsTable.innerHTML = bookingsHTML;
}

// Load cars data
function loadCarsData() {
  if (!carsTableBody) return;
  
  cars = getDummyCars();
  
  if (cars.length === 0) {
    carsTableBody.innerHTML = '<tr><td colspan="7" class="text-center">No cars found</td></tr>';
    return;
  }
  
  let carsHTML = '';
  cars.forEach(car => {
    carsHTML += `
      <tr>
        <td>${car.id}</td>
        <td>
          <img src="${car.image}" alt="${car.make} ${car.model}" class="img-thumbnail" width="80">
        </td>
        <td>${car.make} ${car.model} (${car.year})</td>
        <td><span class="badge bg-${getTypeColor(car.type)}">${capitalizeFirstLetter(car.type)}</span></td>
        <td>$${car.dailyRate}/day</td>
        <td><span class="badge ${car.status === 'available' ? 'bg-success' : 'bg-warning'}">${capitalizeFirstLetter(car.status)}</span></td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="editCar('${car.id}')" data-bs-toggle="modal" data-bs-target="#editCarModal">
              <i class="bi bi-pencil"></i>
            </button>
            <button type="button" class="btn btn-outline-danger" onclick="deleteCar('${car.id}')">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  carsTableBody.innerHTML = carsHTML;
  
  // Add edit and delete car functions to window
  window.editCar = editCar;
  window.deleteCar = deleteCar;
}

// Load bookings data
function loadBookingsData() {
  if (!bookingsTableBody) return;
  
  bookings = getDummyBookings();
  
  if (bookings.length === 0) {
    bookingsTableBody.innerHTML = '<tr><td colspan="7" class="text-center">No bookings found</td></tr>';
    return;
  }
  
  let bookingsHTML = '';
  bookings.forEach(booking => {
    const car = cars.find(car => car.id === booking.carId);
    const user = users.find(user => user.id === booking.userId);
    
    bookingsHTML += `
      <tr>
        <td>${booking.id}</td>
        <td>${user ? `${user.firstName} ${user.lastName}` : 'Unknown User'}</td>
        <td>${car ? `${car.make} ${car.model}` : 'Unknown Car'}</td>
        <td>${formatDate(booking.pickupDate)}</td>
        <td>${formatDate(booking.returnDate)}</td>
        <td><span class="badge ${getStatusBadgeClass(booking.status)}">${capitalizeFirstLetter(booking.status)}</span></td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="viewBooking('${booking.id}')">
              <i class="bi bi-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-success" onclick="updateBookingStatus('${booking.id}', 'completed')">
              <i class="bi bi-check-lg"></i>
            </button>
            <button type="button" class="btn btn-outline-danger" onclick="updateBookingStatus('${booking.id}', 'cancelled')">
              <i class="bi bi-x-lg"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  bookingsTableBody.innerHTML = bookingsHTML;
  
  // Add booking functions to window
  window.viewBooking = viewBooking;
  window.updateBookingStatus = updateBookingStatus;
}

// Load users data
function loadUsersData() {
  if (!usersTableBody) return;
  
  users = getDummyUsers();
  
  if (users.length === 0) {
    usersTableBody.innerHTML = '<tr><td colspan="6" class="text-center">No users found</td></tr>';
    return;
  }
  
  let usersHTML = '';
  users.forEach(user => {
    const userBookings = bookings.filter(booking => booking.userId === user.id);
    
    usersHTML += `
      <tr>
        <td>${user.id}</td>
        <td>${user.firstName} ${user.lastName}</td>
        <td>${user.email}</td>
        <td>${formatDate(user.registeredDate)}</td>
        <td>${userBookings.length}</td>
        <td>
          <div class="btn-group btn-group-sm">
            <button type="button" class="btn btn-outline-primary" onclick="viewUser('${user.id}')">
              <i class="bi bi-eye"></i>
            </button>
            <button type="button" class="btn btn-outline-danger" onclick="deleteUser('${user.id}')">
              <i class="bi bi-trash"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  });
  
  usersTableBody.innerHTML = usersHTML;
  
  // Add user functions to window
  window.viewUser = viewUser;
  window.deleteUser = deleteUser;
}

// Handle adding a new car
function handleAddCar() {
  // Get form values
  const make = document.getElementById('car-make').value;
  const model = document.getElementById('car-model').value;
  const year = document.getElementById('car-year').value;
  const type = document.getElementById('car-type').value;
  const dailyRate = document.getElementById('car-daily-rate').value;
  const capacity = document.getElementById('car-capacity').value;
  const transmission = document.getElementById('car-transmission').value;
  const fuel = document.getElementById('car-fuel').value;
  const imageUrl = document.getElementById('car-image-url').value;
  const description = document.getElementById('car-description').value;
  
  // Basic validation
  if (!make || !model || !year || !type || !dailyRate || !capacity || !transmission || !fuel || !imageUrl || !description) {
    alert('Please fill in all required fields.');
    return;
  }
  
  // Get features
  const features = [];
  document.querySelectorAll('.form-check-input[id^="feature-"]:checked').forEach(checkbox => {
    const featureName = checkbox.id.replace('feature-', '').split('-').map(capitalizeFirstLetter).join(' ');
    features.push(featureName);
  });
  
  // Create new car object
  const newCar = {
    id: 'car' + Math.floor(Math.random() * 10000),
    make,
    model,
    year: parseInt(year),
    type,
    dailyRate: parseFloat(dailyRate),
    capacity: parseInt(capacity),
    transmission,
    fuel,
    image: imageUrl,
    description,
    features,
    status: 'available',
    featured: false
  };
  
  // Add car to list
  cars.push(newCar);
  
  // Hide modal
  const addCarModal = bootstrap.Modal.getInstance(document.getElementById('addCarModal'));
  addCarModal.hide();
  
  // Reset form
  document.getElementById('add-car-form').reset();
  
  // Refresh cars table
  loadCarsData();
  
  // Update dashboard counts
  document.getElementById('total-cars-count').textContent = cars.length;
  document.getElementById('available-cars-count').textContent = cars.filter(car => car.status === 'available').length;
  
  // Show success message
  showAlert('Car added successfully!', 'success', 'admin-cars-tab');
}

// Edit car
function editCar(carId) {
  const car = cars.find(car => car.id === carId);
  if (!car) return;
  
  // Set form values
  document.getElementById('edit-car-id').value = car.id;
  document.getElementById('edit-car-make').value = car.make;
  document.getElementById('edit-car-model').value = car.model;
  document.getElementById('edit-car-year').value = car.year;
  document.getElementById('edit-car-type').value = car.type;
  document.getElementById('edit-car-daily-rate').value = car.dailyRate;
  document.getElementById('edit-car-capacity').value = car.capacity;
  document.getElementById('edit-car-transmission').value = car.transmission;
  document.getElementById('edit-car-fuel').value = car.fuel;
  document.getElementById('edit-car-image-url').value = car.image;
  document.getElementById('edit-car-description').value = car.description;
  
  // Set features checkboxes
  document.querySelectorAll('.form-check-input[id^="edit-feature-"]').forEach(checkbox => {
    const featureName = checkbox.id.replace('edit-feature-', '').split('-').map(capitalizeFirstLetter).join(' ');
    checkbox.checked = car.features.includes(featureName);
  });
}

// Handle updating a car
function handleUpdateCar() {
  const carId = document.getElementById('edit-car-id').value;
  const car = cars.find(car => car.id === carId);
  if (!car) return;
  
  // Update car data
  car.make = document.getElementById('edit-car-make').value;
  car.model = document.getElementById('edit-car-model').value;
  car.year = parseInt(document.getElementById('edit-car-year').value);
  car.type = document.getElementById('edit-car-type').value;
  car.dailyRate = parseFloat(document.getElementById('edit-car-daily-rate').value);
  car.capacity = parseInt(document.getElementById('edit-car-capacity').value);
  car.transmission = document.getElementById('edit-car-transmission').value;
  car.fuel = document.getElementById('edit-car-fuel').value;
  car.image = document.getElementById('edit-car-image-url').value;
  car.description = document.getElementById('edit-car-description').value;
  
  // Update features
  car.features = [];
  document.querySelectorAll('.form-check-input[id^="edit-feature-"]:checked').forEach(checkbox => {
    const featureName = checkbox.id.replace('edit-feature-', '').split('-').map(capitalizeFirstLetter).join(' ');
    car.features.push(featureName);
  });
  
  // Hide modal
  const editCarModal = bootstrap.Modal.getInstance(document.getElementById('editCarModal'));
  editCarModal.hide();
  
  // Refresh cars table
  loadCarsData();
  
  // Show success message
  showAlert('Car updated successfully!', 'success', 'admin-cars-tab');
}

// Delete car
function deleteCar(carId) {
  if (!confirm('Are you sure you want to delete this car?')) return;
  
  // Find car index
  const carIndex = cars.findIndex(car => car.id === carId);
  if (carIndex === -1) return;
  
  // Remove car
  cars.splice(carIndex, 1);
  
  // Refresh cars table
  loadCarsData();
  
  // Update dashboard counts
  document.getElementById('total-cars-count').textContent = cars.length;
  document.getElementById('available-cars-count').textContent = cars.filter(car => car.status === 'available').length;
  
  // Show success message
  showAlert('Car deleted successfully!', 'success', 'admin-cars-tab');
}

// View booking details
function viewBooking(bookingId) {
  const booking = bookings.find(booking => booking.id === bookingId);
  if (!booking) return;
  
  // In a real application, this would show a modal with booking details
  alert(`Viewing booking #${bookingId}`);
}

// Update booking status
function updateBookingStatus(bookingId, newStatus) {
  const booking = bookings.find(booking => booking.id === bookingId);
  if (!booking) return;
  
  // Update booking status
  booking.status = newStatus;
  
  // Refresh bookings table
  loadBookingsData();
  
  // Update dashboard counts
  document.getElementById('admin-active-bookings-count').textContent = bookings.filter(booking => booking.status === 'active').length;
  
  // Refresh recent bookings
  loadRecentBookings();
  
  // Show success message
  showAlert(`Booking status updated to ${capitalizeFirstLetter(newStatus)}!`, 'success', 'admin-bookings-tab');
}

// View user details
function viewUser(userId) {
  const user = users.find(user => user.id === userId);
  if (!user) return;
  
  // In a real application, this would show a modal with user details
  alert(`Viewing user ${user.firstName} ${user.lastName}`);
}

// Delete user
function deleteUser(userId) {
  if (!confirm('Are you sure you want to delete this user?')) return;
  
  // Find user index
  const userIndex = users.findIndex(user => user.id === userId);
  if (userIndex === -1) return;
  
  // Remove user
  users.splice(userIndex, 1);
  
  // Refresh users table
  loadUsersData();
  
  // Update dashboard counts
  document.getElementById('total-users-count').textContent = users.length;
  
  // Show success message
  showAlert('User deleted successfully!', 'success', 'admin-users-tab');
}

// Show alert
function showAlert(message, type, targetId) {
  const alertId = 'temp-alert';
  const existingAlert = document.getElementById(alertId);
  if (existingAlert) {
    existingAlert.remove();
  }
  
  const targetElement = document.getElementById(targetId);
  if (!targetElement) return;
  
  const alertElement = document.createElement('div');
  alertElement.id = alertId;
  alertElement.className = `alert alert-${type} alert-dismissible fade show mb-4`;
  alertElement.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  `;
  
  targetElement.insertBefore(alertElement, targetElement.firstChild);
  
  // Auto dismiss after 3 seconds
  setTimeout(() => {
    const alert = document.getElementById(alertId);
    if (alert) {
      alert.classList.remove('show');
      setTimeout(() => alert.remove(), 300);
    }
  }, 3000);
}

// Helper functions
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function getStatusBadgeClass(status) {
  const statusClasses = {
    'active': 'bg-success',
    'completed': 'bg-secondary',
    'cancelled': 'bg-danger',
    'pending': 'bg-warning'
  };
  return statusClasses[status] || 'bg-secondary';
}

function getTypeColor(type) {
  const typeColors = {
    'economy': 'success',
    'compact': 'info',
    'suv': 'warning',
    'luxury': 'primary',
    'van': 'secondary'
  };
  return typeColors[type] || 'secondary';
}

// Dummy data generators
function getDummyCars() {
  return [
    {
      id: 'car1',
      make: 'Toyota',
      model: 'Corolla',
      year: 2022,
      type: 'economy',
      dailyRate: 45,
      image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      description: 'The Toyota Corolla is a reliable and fuel-efficient compact car, perfect for city driving and short trips.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera'],
      status: 'available',
      featured: true
    },
    {
      id: 'car2',
      make: 'Honda',
      model: 'Civic',
      year: 2023,
      type: 'compact',
      dailyRate: 50,
      image: 'https://images.pexels.com/photos/1009871/pexels-photo-1009871.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      description: 'The Honda Civic offers excellent fuel economy, a comfortable interior, and responsive handling for an enjoyable driving experience.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation'],
      status: 'available',
      featured: true
    },
    {
      id: 'car3',
      make: 'Ford',
      model: 'Explorer',
      year: 2022,
      type: 'suv',
      dailyRate: 85,
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
      capacity: 7,
      transmission: 'automatic',
      fuel: 'gasoline',
      description: 'The Ford Explorer is a spacious three-row SUV with plenty of cargo space, making it ideal for family trips and adventures.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Sunroof'],
      status: 'available',
      featured: true
    },
    {
      id: 'car4',
      make: 'Mercedes-Benz',
      model: 'E-Class',
      year: 2023,
      type: 'luxury',
      dailyRate: 120,
      image: 'https://images.pexels.com/photos/120049/pexels-photo-120049.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      description: 'The Mercedes-Benz E-Class combines luxury, performance, and cutting-edge technology for a premium driving experience.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Leather Seats', 'Sunroof'],
      status: 'rented',
      featured: true
    },
    {
      id: 'car5',
      make: 'Toyota',
      model: 'Sienna',
      year: 2022,
      type: 'van',
      dailyRate: 95,
      image: 'https://images.pexels.com/photos/7428495/pexels-photo-7428495.jpeg',
      capacity: 8,
      transmission: 'automatic',
      fuel: 'hybrid',
      description: 'The Toyota Sienna minivan provides ample space for passengers and cargo, with sliding doors for easy access.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation'],
      status: 'available',
      featured: false
    }
  ];
}

function getDummyBookings() {
  return [
    {
      id: 'BK987654',
      userId: 'user1',
      carId: 'car1',
      pickupDate: '2025-05-15',
      returnDate: '2025-05-20',
      location: 'Airport Terminal',
      status: 'active',
      total: 225.00,
      createdAt: '2025-05-10T10:30:00'
    },
    {
      id: 'BK567890',
      userId: 'user2',
      carId: 'car2',
      pickupDate: '2025-06-10',
      returnDate: '2025-06-15',
      location: 'Downtown',
      status: 'active',
      total: 250.00,
      createdAt: '2025-06-01T14:15:00'
    },
    {
      id: 'BK123456',
      userId: 'user3',
      carId: 'car3',
      pickupDate: '2025-01-05',
      returnDate: '2025-01-10',
      location: 'North Branch',
      status: 'completed',
      total: 425.00,
      createdAt: '2025-01-01T09:45:00'
    },
    {
      id: 'BK234567',
      userId: 'user1',
      carId: 'car4',
      pickupDate: '2025-02-20',
      returnDate: '2025-02-25',
      location: 'East Branch',
      status: 'completed',
      total: 550.00,
      createdAt: '2025-02-15T16:20:00'
    },
    {
      id: 'BK345678',
      userId: 'user4',
      carId: 'car5',
      pickupDate: '2025-07-01',
      returnDate: '2025-07-07',
      location: 'Airport Terminal',
      status: 'pending',
      total: 665.00,
      createdAt: '2025-06-25T11:10:00'
    }
  ];
}

function getDummyUsers() {
  return [
    {
      id: 'user1',
      firstName: 'John',
      lastName: 'Doe',
      email: 'john.doe@example.com',
      phone: '(555) 123-4567',
      registeredDate: '2025-01-01'
    },
    {
      id: 'user2',
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane.smith@example.com',
      phone: '(555) 234-5678',
      registeredDate: '2025-01-15'
    },
    {
      id: 'user3',
      firstName: 'Michael',
      lastName: 'Johnson',
      email: 'michael.johnson@example.com',
      phone: '(555) 345-6789',
      registeredDate: '2025-02-10'
    },
    {
      id: 'user4',
      firstName: 'Sarah',
      lastName: 'Williams',
      email: 'sarah.williams@example.com',
      phone: '(555) 456-7890',
      registeredDate: '2025-03-05'
    }
  ];
}
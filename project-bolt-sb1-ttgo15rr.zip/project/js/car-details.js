import { fetchCarById, saveBooking, getTypeColor, capitalizeFirstLetter } from './main.js';

// DOM elements
const carDetailsContainer = document.getElementById('car-details-container');
const bookingForm = document.getElementById('booking-form');
const confirmBookingBtn = document.getElementById('confirm-booking');
const sameLocationCheckbox = document.getElementById('same-location');
const returnLocationSelect = document.getElementById('return-location');

// Get car ID from URL
const urlParams = new URLSearchParams(window.location.search);
const carId = urlParams.get('id');

let currentCar = null;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  if (!carId) {
    showErrorMessage('Car ID is missing. Please go back to the cars page and try again.');
    return;
  }

  try {
    // Load car details
    currentCar = await fetchCarById(carId);
    if (!currentCar) {
      showErrorMessage('Car not found. It may have been removed or is no longer available.');
      return;
    }
    
    renderCarDetails();
    
    // Set up booking form event listeners
    if (sameLocationCheckbox) {
      sameLocationCheckbox.addEventListener('change', handleSameLocationChange);
    }
    
    if (confirmBookingBtn) {
      confirmBookingBtn.addEventListener('click', handleBookingSubmit);
    }
    
    const pickupDateInput = document.getElementById('pickup-date');
    const returnDateInput = document.getElementById('return-date');
    
    if (pickupDateInput && returnDateInput) {
      pickupDateInput.addEventListener('change', updateBookingSummary);
      returnDateInput.addEventListener('change', updateBookingSummary);
      
      // Set min date to today
      const today = new Date().toISOString().split('T')[0];
      pickupDateInput.min = today;
      returnDateInput.min = today;
    }
    
    const pickupLocationSelect = document.getElementById('pickup-location');
    if (pickupLocationSelect) {
      pickupLocationSelect.addEventListener('change', () => {
        if (sameLocationCheckbox.checked) {
          returnLocationSelect.value = pickupLocationSelect.value;
        }
        updateBookingSummary();
      });
    }
    
    if (returnLocationSelect) {
      returnLocationSelect.addEventListener('change', updateBookingSummary);
    }
    
  } catch (error) {
    console.error('Error loading car details:', error);
    showErrorMessage('An error occurred while loading car details. Please try again later.');
  }
});

// Render car details
function renderCarDetails() {
  if (!carDetailsContainer || !currentCar) return;
  
  // Update page title
  document.title = `${currentCar.make} ${currentCar.model} - DriveEasy Car Rentals`;
  
  carDetailsContainer.innerHTML = `
    <div class="row">
      <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
          <div class="car-gallery position-relative">
            <img src="${currentCar.image}" class="img-fluid rounded-top" id="main-car-image" alt="${currentCar.make} ${currentCar.model}">
            <span class="badge bg-${getTypeColor(currentCar.type)} position-absolute top-0 end-0 m-3">${capitalizeFirstLetter(currentCar.type)}</span>
          </div>
          <div class="card-body">
            <h1 class="card-title h3">${currentCar.make} ${currentCar.model} <small class="text-muted">${currentCar.year}</small></h1>
            <div class="d-flex flex-wrap mb-3">
              <div class="me-4 mb-2">
                <i class="bi bi-people-fill me-1 text-primary"></i>
                <span>${currentCar.capacity} Passengers</span>
              </div>
              <div class="me-4 mb-2">
                <i class="bi bi-gear-fill me-1 text-primary"></i>
                <span>${capitalizeFirstLetter(currentCar.transmission)}</span>
              </div>
              <div class="me-4 mb-2">
                <i class="bi bi-fuel-pump-fill me-1 text-primary"></i>
                <span>${capitalizeFirstLetter(currentCar.fuel)}</span>
              </div>
              <div class="mb-2">
                <i class="bi bi-speedometer2 me-1 text-primary"></i>
                <span>Unlimited Mileage</span>
              </div>
            </div>
            <hr>
            <h5>Description</h5>
            <p>${currentCar.description}</p>
            <hr>
            <h5>Features</h5>
            <div class="row">
              ${renderFeaturesList(currentCar.features)}
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="card border-0 shadow-sm sticky-top" style="top: 20px; z-index: 100;">
          <div class="card-body">
            <h4 class="card-title mb-4">Rental Summary</h4>
            <div class="d-flex justify-content-between align-items-center mb-3">
              <h5 class="mb-0">Daily Rate</h5>
              <h4 class="text-primary mb-0">$${currentCar.dailyRate}</h4>
            </div>
            <ul class="list-unstyled mb-4">
              <li class="d-flex justify-content-between mb-2">
                <span>Insurance</span>
                <span>Included</span>
              </li>
              <li class="d-flex justify-content-between mb-2">
                <span>Roadside Assistance</span>
                <span>Included</span>
              </li>
              <li class="d-flex justify-content-between mb-2">
                <span>Unlimited Mileage</span>
                <span>Included</span>
              </li>
            </ul>
            <button type="button" class="btn btn-primary btn-lg w-100 mb-3" data-bs-toggle="modal" data-bs-target="#bookingModal">
              Book Now
            </button>
            <p class="text-muted small mb-0 text-center">No credit card required to reserve</p>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Set car ID in booking form
  const carIdInput = document.getElementById('car-id');
  if (carIdInput) {
    carIdInput.value = currentCar.id;
  }
}

// Render features list
function renderFeaturesList(features) {
  if (!features || features.length === 0) {
    return '<div class="col-12">No specific features listed.</div>';
  }
  
  return features.map(feature => `
    <div class="col-md-6 mb-2">
      <i class="bi bi-check-circle-fill text-success me-2"></i>
      ${feature}
    </div>
  `).join('');
}

// Show error message
function showErrorMessage(message) {
  if (!carDetailsContainer) return;
  
  carDetailsContainer.innerHTML = `
    <div class="alert alert-danger" role="alert">
      <h4 class="alert-heading">Error</h4>
      <p>${message}</p>
      <hr>
      <div class="text-center">
        <a href="/pages/cars.html" class="btn btn-primary">Return to Cars</a>
      </div>
    </div>
  `;
}

// Handle same location checkbox
function handleSameLocationChange() {
  if (!sameLocationCheckbox || !returnLocationSelect) return;
  
  const pickupLocationSelect = document.getElementById('pickup-location');
  
  if (sameLocationCheckbox.checked) {
    returnLocationSelect.value = pickupLocationSelect.value;
    returnLocationSelect.disabled = true;
  } else {
    returnLocationSelect.disabled = false;
  }
  
  updateBookingSummary();
}

// Update booking summary
function updateBookingSummary() {
  const bookingSummary = document.getElementById('booking-summary');
  if (!bookingSummary || !currentCar) return;
  
  const pickupDate = document.getElementById('pickup-date').value;
  const returnDate = document.getElementById('return-date').value;
  const pickupLocation = document.getElementById('pickup-location').value;
  const returnLocation = document.getElementById('return-location').value;
  
  if (!pickupDate || !returnDate) {
    bookingSummary.innerHTML = '<p class="text-center text-muted">Please select dates to see summary</p>';
    return;
  }
  
  // Calculate number of days
  const start = new Date(pickupDate);
  const end = new Date(returnDate);
  const diffTime = Math.abs(end - start);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // Minimum 1 day
  
  // Calculate total price
  const basePrice = currentCar.dailyRate * diffDays;
  const tax = basePrice * 0.08; // 8% tax
  const total = basePrice + tax;
  
  // Format location names
  const pickupLocationName = getLocationName(pickupLocation);
  const returnLocationName = getLocationName(returnLocation);
  
  bookingSummary.innerHTML = `
    <div class="booking-summary-item">
      <span>Car:</span>
      <span>${currentCar.make} ${currentCar.model}</span>
    </div>
    <div class="booking-summary-item">
      <span>Pickup:</span>
      <span>${formatDate(pickupDate)} at ${pickupLocationName}</span>
    </div>
    <div class="booking-summary-item">
      <span>Return:</span>
      <span>${formatDate(returnDate)} at ${returnLocationName}</span>
    </div>
    <div class="booking-summary-item">
      <span>Duration:</span>
      <span>${diffDays} day${diffDays !== 1 ? 's' : ''}</span>
    </div>
    <div class="booking-summary-item">
      <span>Daily Rate:</span>
      <span>$${currentCar.dailyRate.toFixed(2)}</span>
    </div>
    <div class="booking-summary-item">
      <span>Subtotal:</span>
      <span>$${basePrice.toFixed(2)}</span>
    </div>
    <div class="booking-summary-item">
      <span>Tax (8%):</span>
      <span>$${tax.toFixed(2)}</span>
    </div>
    <div class="booking-summary-item booking-total">
      <span>Total:</span>
      <span>$${total.toFixed(2)}</span>
    </div>
  `;
}

// Handle booking form submission
async function handleBookingSubmit() {
  if (!currentCar) return;
  
  const pickupDate = document.getElementById('pickup-date').value;
  const returnDate = document.getElementById('return-date').value;
  const pickupLocation = document.getElementById('pickup-location').value;
  const returnLocation = document.getElementById('return-location').value;
  const firstName = document.getElementById('first-name').value;
  const lastName = document.getElementById('last-name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const termsCheck = document.getElementById('terms-check').checked;
  
  // Basic validation
  if (!pickupDate || !returnDate || !pickupLocation || !returnLocation || 
      !firstName || !lastName || !email || !phone || !termsCheck) {
    alert('Please fill in all required fields and accept the terms and conditions.');
    return;
  }
  
  // Create booking data
  const bookingData = {
    carId: currentCar.id,
    car: {
      make: currentCar.make,
      model: currentCar.model,
      year: currentCar.year,
      dailyRate: currentCar.dailyRate
    },
    pickupDate,
    returnDate,
    pickupLocation,
    returnLocation,
    customer: {
      firstName,
      lastName,
      email,
      phone
    },
    // Calculate number of days and total
    days: calculateDays(pickupDate, returnDate),
    total: calculateTotal(currentCar.dailyRate, pickupDate, returnDate)
  };
  
  try {
    // Show loading state
    confirmBookingBtn.disabled = true;
    confirmBookingBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
    
    // Save booking
    const confirmedBooking = await saveBooking(bookingData);
    
    // Hide booking modal
    const bookingModal = bootstrap.Modal.getInstance(document.getElementById('bookingModal'));
    bookingModal.hide();
    
    // Show confirmation details
    const confirmationDetails = document.getElementById('confirmation-details');
    if (confirmationDetails) {
      confirmationDetails.innerHTML = `
        <div class="mb-3">
          <strong>Booking Reference:</strong> ${confirmedBooking.id}
        </div>
        <div class="mb-3">
          <strong>Car:</strong> ${currentCar.make} ${currentCar.model} (${currentCar.year})
        </div>
        <div class="mb-3">
          <strong>Pickup:</strong> ${formatDate(pickupDate)} at ${getLocationName(pickupLocation)}
        </div>
        <div class="mb-3">
          <strong>Return:</strong> ${formatDate(returnDate)} at ${getLocationName(returnLocation)}
        </div>
        <div class="mb-3">
          <strong>Total Payment:</strong> $${confirmBooking.total.toFixed(2)}
        </div>
      `;
    }
    
    // Show confirmation modal
    const confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
    confirmationModal.show();
    
  } catch (error) {
    console.error('Error saving booking:', error);
    alert('An error occurred while processing your booking. Please try again later.');
  } finally {
    // Reset button state
    confirmBookingBtn.disabled = false;
    confirmBookingBtn.innerHTML = 'Confirm Booking';
  }
}

// Helper functions
function calculateDays(startDate, endDate) {
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diffTime = Math.abs(end - start);
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // Minimum 1 day
}

function calculateTotal(dailyRate, startDate, endDate) {
  const days = calculateDays(startDate, endDate);
  const basePrice = dailyRate * days;
  const tax = basePrice * 0.08; // 8% tax
  return basePrice + tax;
}

function formatDate(dateString) {
  const options = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
}

function getLocationName(locationCode) {
  const locations = {
    'airport': 'Airport Terminal',
    'downtown': 'Downtown',
    'north': 'North Branch',
    'east': 'East Branch'
  };
  return locations[locationCode] || locationCode;
}
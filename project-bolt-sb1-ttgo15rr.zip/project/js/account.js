import { checkLoginStatus } from './main.js';

// Redirect to home if not logged in
if (!checkLoginStatus()) {
  window.location.href = '/?redirect=account';
}

// DOM elements
const accountNav = document.getElementById('account-nav');
const logoutBtn = document.getElementById('logout-btn');
const profileForm = document.getElementById('profile-form');
const passwordForm = document.getElementById('password-form');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  // Add event listeners for tab navigation
  if (accountNav) {
    const tabLinks = accountNav.querySelectorAll('[data-tab]');
    tabLinks.forEach(link => {
      link.addEventListener('click', handleTabChange);
    });
  }
  
  // Add event listener for logout
  if (logoutBtn) {
    logoutBtn.addEventListener('click', handleLogout);
  }
  
  // Add event listeners for forms
  if (profileForm) {
    profileForm.addEventListener('submit', handleProfileUpdate);
    loadUserProfile();
  }
  
  if (passwordForm) {
    passwordForm.addEventListener('submit', handlePasswordUpdate);
  }
  
  // Check if we have a tab in the URL hash
  const hash = window.location.hash.substring(1);
  if (hash) {
    const tabLink = document.querySelector(`[data-tab="${hash}"]`);
    if (tabLink) {
      tabLink.click();
    }
  }
  
  // Load bookings data
  loadBookingsData();
  
  // Initialize bookings tabs
  const bookingsNav = document.getElementById('bookings-nav');
  if (bookingsNav) {
    const bookingTabs = bookingsNav.querySelectorAll('[data-booking-type]');
    bookingTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        const type = tab.dataset.bookingType;
        
        // Update active tab
        bookingTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        
        // Filter bookings by type
        displayBookings(type);
      });
    });
  }
});

// Handle tab changes
function handleTabChange(e) {
  e.preventDefault();
  
  // Get the target tab
  const tabName = this.dataset.tab;
  
  // Remove active class from all tabs
  const allTabLinks = accountNav.querySelectorAll('[data-tab]');
  allTabLinks.forEach(link => {
    link.classList.remove('active');
  });
  
  // Add active class to clicked tab
  this.classList.add('active');
  
  // Hide all tab content
  const allTabContent = document.querySelectorAll('.tab-content');
  allTabContent.forEach(content => {
    content.classList.add('d-none');
  });
  
  // Show selected tab content
  const targetContent = document.getElementById(`${tabName}-tab`);
  if (targetContent) {
    targetContent.classList.remove('d-none');
  }
  
  // Update URL hash
  window.location.hash = tabName;
}

// Handle logout
function handleLogout(e) {
  e.preventDefault();
  localStorage.removeItem('user');
  window.location.href = '/';
}

// Load user profile
function loadUserProfile() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  
  // Set form values
  if (user.firstName) document.getElementById('profile-first-name').value = user.firstName;
  if (user.lastName) document.getElementById('profile-last-name').value = user.lastName;
  if (user.email) document.getElementById('profile-email').value = user.email;
  
  // For demo purposes, we'll add some dummy data
  document.getElementById('profile-phone').value = user.phone || '(555) 123-4567';
  document.getElementById('profile-address').value = user.address || '123 Main St';
  document.getElementById('profile-city').value = user.city || 'New York';
  document.getElementById('profile-state').value = user.state || 'NY';
  document.getElementById('profile-zip').value = user.zip || '10001';
}

// Handle profile update
function handleProfileUpdate(e) {
  e.preventDefault();
  
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  
  // Update user data
  user.firstName = document.getElementById('profile-first-name').value;
  user.lastName = document.getElementById('profile-last-name').value;
  user.phone = document.getElementById('profile-phone').value;
  user.address = document.getElementById('profile-address').value;
  user.city = document.getElementById('profile-city').value;
  user.state = document.getElementById('profile-state').value;
  user.zip = document.getElementById('profile-zip').value;
  
  // Save updated user data
  localStorage.setItem('user', JSON.stringify(user));
  
  // Show success message
  showAlert('Profile updated successfully!', 'success', 'profile-tab');
  
  // Add to recent activity
  addActivity('Updated profile information');
}

// Handle password update
function handlePasswordUpdate(e) {
  e.preventDefault();
  
  const currentPassword = document.getElementById('current-password').value;
  const newPassword = document.getElementById('new-password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  
  // Simple validation
  if (!currentPassword || !newPassword || !confirmPassword) {
    showAlert('Please fill in all fields.', 'danger', 'password-tab');
    return;
  }
  
  if (newPassword !== confirmPassword) {
    showAlert('New passwords do not match.', 'danger', 'password-tab');
    return;
  }
  
  // For demo purposes, we'll just show success
  showAlert('Password updated successfully!', 'success', 'password-tab');
  document.getElementById('password-form').reset();
  
  // Add to recent activity
  addActivity('Changed account password');
}

// Show alert
function showAlert(message, type, targetId) {
  const alertId = 'temp-alert';
  const existingAlert = document.getElementById(alertId);
  if (existingAlert) {
    existingAlert.remove();
  }
  
  const targetElement = document.getElementById(targetId);
  if (!targetElement) return;
  
  const alertElement = document.createElement('div');
  alertElement.id = alertId;
  alertElement.className = `alert alert-${type} alert-dismissible fade show mt-3`;
  alertElement.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  `;
  
  targetElement.insertBefore(alertElement, targetElement.firstChild);
  
  // Auto dismiss after 3 seconds
  setTimeout(() => {
    const alert = document.getElementById(alertId);
    if (alert) {
      alert.classList.remove('show');
      setTimeout(() => alert.remove(), 300);
    }
  }, 3000);
}

// Add activity to recent activity list
function addActivity(activity) {
  const recentActivity = document.getElementById('recent-activity');
  if (!recentActivity) return;
  
  // Get current date and time
  const now = new Date();
  const dateTimeString = now.toLocaleString();
  
  // Create new activity row
  const newRow = document.createElement('tr');
  newRow.innerHTML = `
    <td>${dateTimeString}</td>
    <td>${activity}</td>
  `;
  
  // Clear "no activity" message if it exists
  if (recentActivity.querySelector('td[colspan="2"]')) {
    recentActivity.innerHTML = '';
  }
  
  // Add to beginning of table
  recentActivity.insertBefore(newRow, recentActivity.firstChild);
}

// Load bookings data
function loadBookingsData() {
  // For demo purposes, we'll create some dummy bookings
  const bookings = getDummyBookings();
  
  // Update counts on dashboard
  const activeBookingsCount = document.getElementById('active-bookings-count');
  const pastBookingsCount = document.getElementById('past-bookings-count');
  
  if (activeBookingsCount) {
    activeBookingsCount.textContent = bookings.filter(b => b.status === 'active').length;
  }
  
  if (pastBookingsCount) {
    pastBookingsCount.textContent = bookings.filter(b => b.status === 'completed').length;
  }
  
  // Display active bookings by default
  displayBookings('active');
}

// Display bookings by type (active/past)
function displayBookings(type) {
  const bookingsContainer = document.getElementById('bookings-container');
  if (!bookingsContainer) return;
  
  const bookings = getDummyBookings();
  let filteredBookings;
  
  if (type === 'active') {
    filteredBookings = bookings.filter(b => b.status === 'active');
  } else {
    filteredBookings = bookings.filter(b => b.status === 'completed');
  }
  
  if (filteredBookings.length === 0) {
    bookingsContainer.innerHTML = `
      <div class="alert alert-info">
        No ${type} bookings found.
      </div>
    `;
    return;
  }
  
  let bookingsHTML = '';
  filteredBookings.forEach(booking => {
    bookingsHTML += `
      <div class="card mb-3 border-0 shadow-sm">
        <div class="card-body">
          <div class="row">
            <div class="col-md-3">
              <img src="${booking.car.image}" alt="${booking.car.make} ${booking.car.model}" class="img-fluid rounded">
            </div>
            <div class="col-md-6">
              <h5 class="card-title">${booking.car.make} ${booking.car.model} (${booking.car.year})</h5>
              <p class="card-text text-muted mb-2">Booking #${booking.id}</p>
              <div class="d-flex mb-2">
                <div class="me-3">
                  <i class="bi bi-calendar3 me-1 text-primary"></i>
                  <span>${formatDate(booking.pickupDate)}</span>
                </div>
                <div>
                  <i class="bi bi-arrow-right me-1 text-primary"></i>
                  <span>${formatDate(booking.returnDate)}</span>
                </div>
              </div>
              <p class="mb-0">
                <i class="bi bi-geo-alt me-1 text-primary"></i>
                <span>${booking.location}</span>
              </p>
            </div>
            <div class="col-md-3 text-md-end">
              <span class="badge ${getStatusBadgeClass(booking.status)} mb-2">${capitalizeFirstLetter(booking.status)}</span>
              <p class="mb-2"><strong>Total: $${booking.total.toFixed(2)}</strong></p>
              <div class="btn-group">
                <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#bookingDetailsModal" data-booking-id="${booking.id}">
                  View Details
                </button>
                ${type === 'active' ? `
                  <button type="button" class="btn btn-sm btn-outline-danger">
                    Cancel
                  </button>
                ` : ''}
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  });
  
  bookingsContainer.innerHTML = bookingsHTML;
}

// Helper functions
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString('en-US', options);
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function getStatusBadgeClass(status) {
  const statusClasses = {
    'active': 'bg-success',
    'completed': 'bg-secondary',
    'cancelled': 'bg-danger',
    'pending': 'bg-warning'
  };
  return statusClasses[status] || 'bg-secondary';
}

// Get dummy bookings data
function getDummyBookings() {
  return [
    {
      id: 'BK987654',
      car: {
        make: 'Toyota',
        model: 'Corolla',
        year: 2022,
        image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg'
      },
      pickupDate: '2025-05-15',
      returnDate: '2025-05-20',
      location: 'Airport Terminal',
      status: 'active',
      total: 225.00
    },
    {
      id: 'BK567890',
      car: {
        make: 'Honda',
        model: 'Civic',
        year: 2023,
        image: 'https://images.pexels.com/photos/1009871/pexels-photo-1009871.jpeg'
      },
      pickupDate: '2025-06-10',
      returnDate: '2025-06-15',
      location: 'Downtown',
      status: 'active',
      total: 250.00
    },
    {
      id: 'BK123456',
      car: {
        make: 'Ford',
        model: 'Explorer',
        year: 2022,
        image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg'
      },
      pickupDate: '2025-01-05',
      returnDate: '2025-01-10',
      location: 'North Branch',
      status: 'completed',
      total: 425.00
    },
    {
      id: 'BK234567',
      car: {
        make: 'BMW',
        model: '3 Series',
        year: 2023,
        image: 'https://images.pexels.com/photos/6894085/pexels-photo-6894085.jpeg'
      },
      pickupDate: '2025-02-20',
      returnDate: '2025-02-25',
      location: 'East Branch',
      status: 'completed',
      total: 550.00
    }
  ];
}
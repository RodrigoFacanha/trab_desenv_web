import 'bootstrap/dist/js/bootstrap.bundle.min.js';

// DOM elements
const headerContainer = document.getElementById('header-container');
const footerContainer = document.getElementById('footer-container');

// Initialize tooltips and popovers
document.addEventListener('DOMContentLoaded', () => {
  // Initialize Bootstrap components
  const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
  const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

  const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]');
  const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl));

  // Load header and footer
  loadHeader();
  loadFooter();
});

// Load header content
function loadHeader() {
  if (!headerContainer) return;

  const isLoggedIn = checkLoginStatus();
  const currentPage = window.location.pathname;

  headerContainer.innerHTML = `
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
      <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="/">
          <i class="bi bi-car-front fs-3 me-2 text-primary"></i>
          <span class="fw-bold">DriveEasy</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link ${currentPage === '/' ? 'active' : ''}" href="/">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link ${currentPage.includes('/cars.html') ? 'active' : ''}" href="/pages/cars.html">Cars</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/#how-it-works">How It Works</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/pages/contact.html">Contact</a>
            </li>
          </ul>
          <ul class="navbar-nav ms-auto">
            ${isLoggedIn ? `
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                  data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="bi bi-person-circle me-1"></i>
                  ${getUserName() || 'My Account'}
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="/pages/account.html">Dashboard</a></li>
                  <li><a class="dropdown-item" href="/pages/account.html#bookings">My Bookings</a></li>
                  <li><a class="dropdown-item" href="/pages/account.html#profile">Profile Settings</a></li>
                  ${isAdmin() ? '<li><a class="dropdown-item" href="/pages/admin.html">Admin Panel</a></li>' : ''}
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="#" id="logout-link">Logout</a></li>
                </ul>
              </li>
            ` : `
              <li class="nav-item">
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">
                  <i class="bi bi-box-arrow-in-right me-1"></i> Login
                </a>
              </li>
              <li class="nav-item">
                <a class="btn btn-primary btn-sm mt-1" href="#" data-bs-toggle="modal" data-bs-target="#registerModal">
                  Register
                </a>
              </li>
            `}
          </ul>
        </div>
      </div>
    </nav>

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="loginModalLabel">Login to Your Account</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="login-form">
              <div class="mb-3">
                <label for="login-email" class="form-label">Email address</label>
                <input type="email" class="form-control" id="login-email" required>
              </div>
              <div class="mb-3">
                <label for="login-password" class="form-label">Password</label>
                <input type="password" class="form-control" id="login-password" required>
              </div>
              <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="remember-me">
                <label class="form-check-label" for="remember-me">Remember me</label>
              </div>
              <button type="submit" class="btn btn-primary w-100">Login</button>
              <div class="text-center mt-3">
                <a href="#" class="text-decoration-none">Forgot password?</a>
              </div>
            </form>
          </div>
          <div class="modal-footer justify-content-center">
            <p class="mb-0">Don't have an account? <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#registerModal" data-bs-dismiss="modal">Register now</a></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Register Modal -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="registerModalLabel">Create an Account</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="register-form">
              <div class="row g-3">
                <div class="col-md-6">
                  <label for="register-first-name" class="form-label">First Name</label>
                  <input type="text" class="form-control" id="register-first-name" required>
                </div>
                <div class="col-md-6">
                  <label for="register-last-name" class="form-label">Last Name</label>
                  <input type="text" class="form-control" id="register-last-name" required>
                </div>
                <div class="col-12">
                  <label for="register-email" class="form-label">Email address</label>
                  <input type="email" class="form-control" id="register-email" required>
                </div>
                <div class="col-12">
                  <label for="register-phone" class="form-label">Phone Number</label>
                  <input type="tel" class="form-control" id="register-phone" required>
                </div>
                <div class="col-12">
                  <label for="register-password" class="form-label">Password</label>
                  <input type="password" class="form-control" id="register-password" required>
                </div>
                <div class="col-12">
                  <label for="register-confirm-password" class="form-label">Confirm Password</label>
                  <input type="password" class="form-control" id="register-confirm-password" required>
                </div>
                <div class="col-12">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="terms-checkbox" required>
                    <label class="form-check-label" for="terms-checkbox">
                      I agree to the <a href="#" class="text-decoration-none">Terms and Conditions</a>
                    </label>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary w-100">Register</button>
                </div>
              </div>
            </form>
          </div>
          <div class="modal-footer justify-content-center">
            <p class="mb-0">Already have an account? <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#loginModal" data-bs-dismiss="modal">Login</a></p>
          </div>
        </div>
      </div>
    </div>
  `;

  // Add event listeners for login and register forms
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const logoutLink = document.getElementById('logout-link');

  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }

  if (registerForm) {
    registerForm.addEventListener('submit', handleRegister);
  }

  if (logoutLink) {
    logoutLink.addEventListener('click', handleLogout);
  }
}

// Load footer content
function loadFooter() {
  if (!footerContainer) return;

  footerContainer.innerHTML = `
    <footer class="bg-dark text-white pt-5 pb-4">
      <div class="container">
        <div class="row g-4">
          <div class="col-lg-3 col-md-6">
            <h5 class="mb-4">DriveEasy</h5>
            <p class="mb-4">Premium car rental service for all your travel needs. Experience luxury and comfort on the road.</p>
            <div class="d-flex">
              <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
              <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
              <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
              <a href="#" class="text-white"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="mb-4">Quick Links</h5>
            <ul class="list-unstyled">
              <li class="mb-2"><a href="/" class="text-white text-decoration-none">Home</a></li>
              <li class="mb-2"><a href="/pages/cars.html" class="text-white text-decoration-none">Cars</a></li>
              <li class="mb-2"><a href="/#how-it-works" class="text-white text-decoration-none">How It Works</a></li>
              <li class="mb-2"><a href="/pages/contact.html" class="text-white text-decoration-none">Contact</a></li>
              <li><a href="/pages/account.html" class="text-white text-decoration-none">My Account</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="mb-4">Contact Us</h5>
            <ul class="list-unstyled">
              <li class="mb-2"><i class="bi bi-geo-alt me-2"></i> 123 Main Street, New York, NY 10001</li>
              <li class="mb-2"><i class="bi bi-telephone me-2"></i> (123) 456-7890</li>
              <li class="mb-2"><i class="bi bi-envelope me-2"></i> info@driveeasy.com</li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6">
            <h5 class="mb-4">Newsletter</h5>
            <p>Subscribe to receive updates and special offers</p>
            <form class="mb-3">
              <div class="input-group">
                <input type="email" class="form-control" placeholder="Your email" required>
                <button class="btn btn-primary" type="submit">Subscribe</button>
              </div>
            </form>
            <div>
              <img src="https://via.placeholder.com/120x30?text=Payment+Methods" alt="Payment methods" class="img-fluid">
            </div>
          </div>
        </div>
        <hr class="my-4">
        <div class="row">
          <div class="col-md-6 text-center text-md-start">
            <p class="mb-0">&copy; 2025 DriveEasy. All rights reserved.</p>
          </div>
          <div class="col-md-6 text-center text-md-end">
            <a href="#" class="text-white text-decoration-none me-3">Privacy Policy</a>
            <a href="#" class="text-white text-decoration-none me-3">Terms of Service</a>
            <a href="#" class="text-white text-decoration-none">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  `;
}

// Authentication functions
function checkLoginStatus() {
  // In a real application, this would check session or token
  const user = localStorage.getItem('user');
  return !!user;
}

function isAdmin() {
  // Check if the current user is an admin
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  return user.isAdmin === true;
}

function getUserName() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  if (user.firstName) {
    return user.firstName;
  }
  return null;
}

function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  // For demo purposes - in a real app, this would call an API
  if (email && password) {
    // Check if it's the admin login
    if (email === 'admin@driveeasy.com' && password === 'admin123') {
      const adminUser = {
        id: 'admin1',
        email: email,
        firstName: 'Admin',
        lastName: 'User',
        isAdmin: true
      };
      localStorage.setItem('user', JSON.stringify(adminUser));
      window.location.href = '/pages/admin.html';
      return;
    }

    // Regular user login
    const user = {
      id: 'user' + Math.floor(Math.random() * 1000),
      email: email,
      firstName: 'John',
      lastName: 'Doe'
    };
    localStorage.setItem('user', JSON.stringify(user));
    
    // Close the modal and refresh
    const loginModal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
    loginModal.hide();
    window.location.reload();
  } else {
    alert('Please enter both email and password');
  }
}

function handleRegister(e) {
  e.preventDefault();
  const firstName = document.getElementById('register-first-name').value;
  const lastName = document.getElementById('register-last-name').value;
  const email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;
  const confirmPassword = document.getElementById('register-confirm-password').value;

  // Basic validation
  if (password !== confirmPassword) {
    alert('Passwords do not match');
    return;
  }

  // For demo purposes - in a real app, this would call an API
  if (firstName && lastName && email && password) {
    const user = {
      id: 'user' + Math.floor(Math.random() * 1000),
      firstName: firstName,
      lastName: lastName,
      email: email
    };
    localStorage.setItem('user', JSON.stringify(user));
    
    // Close the modal and refresh
    const registerModal = bootstrap.Modal.getInstance(document.getElementById('registerModal'));
    registerModal.hide();
    window.location.reload();
  } else {
    alert('Please fill out all fields');
  }
}

function handleLogout(e) {
  e.preventDefault();
  localStorage.removeItem('user');
  window.location.href = '/';
}

// API helper functions (for demo purposes)
export async function fetchCars() {
  // This would normally fetch from a real API
  // Using a setTimeout to simulate network delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getDummyCars());
    }, 800);
  });
}

export async function fetchCarById(id) {
  // Simulate API call to get a specific car
  const cars = getDummyCars();
  return new Promise((resolve) => {
    setTimeout(() => {
      const car = cars.find(car => car.id === id);
      resolve(car || null);
    }, 500);
  });
}

export async function saveBooking(bookingData) {
  // Simulate API call to save a booking
  return new Promise((resolve) => {
    setTimeout(() => {
      // Generate a booking reference
      const bookingRef = 'BK' + Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
      resolve({
        ...bookingData,
        id: bookingRef,
        status: 'confirmed',
        createdAt: new Date().toISOString()
      });
    }, 1000);
  });
}

// Generate dummy data
export function getDummyCars() {
  return [
    {
      id: '1',
      make: 'Toyota',
      model: 'Corolla',
      year: 2022,
      type: 'economy',
      dailyRate: 45,
      image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: true,
      description: 'The Toyota Corolla is a reliable and fuel-efficient compact car, perfect for city driving and short trips.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera']
    },
    {
      id: '2',
      make: 'Honda',
      model: 'Civic',
      year: 2023,
      type: 'compact',
      dailyRate: 50,
      image: 'https://images.pexels.com/photos/1009871/pexels-photo-1009871.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: true,
      description: 'The Honda Civic offers excellent fuel economy, a comfortable interior, and responsive handling for an enjoyable driving experience.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation']
    },
    {
      id: '3',
      make: 'Ford',
      model: 'Explorer',
      year: 2022,
      type: 'suv',
      dailyRate: 85,
      image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
      capacity: 7,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: true,
      description: 'The Ford Explorer is a spacious three-row SUV with plenty of cargo space, making it ideal for family trips and adventures.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Sunroof']
    },
    {
      id: '4',
      make: 'Mercedes-Benz',
      model: 'E-Class',
      year: 2023,
      type: 'luxury',
      dailyRate: 120,
      image: 'https://images.pexels.com/photos/120049/pexels-photo-120049.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: true,
      description: 'The Mercedes-Benz E-Class combines luxury, performance, and cutting-edge technology for a premium driving experience.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Leather Seats', 'Sunroof']
    },
    {
      id: '5',
      make: 'Toyota',
      model: 'Sienna',
      year: 2022,
      type: 'van',
      dailyRate: 95,
      image: 'https://images.pexels.com/photos/7428495/pexels-photo-7428495.jpeg',
      capacity: 8,
      transmission: 'automatic',
      fuel: 'hybrid',
      featured: false,
      description: 'The Toyota Sienna minivan provides ample space for passengers and cargo, with sliding doors for easy access.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation']
    },
    {
      id: '6',
      make: 'Chevrolet',
      model: 'Malibu',
      year: 2022,
      type: 'economy',
      dailyRate: 55,
      image: 'https://images.pexels.com/photos/707046/pexels-photo-707046.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: false,
      description: 'The Chevrolet Malibu is a stylish midsize sedan with a comfortable ride and good fuel economy.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera']
    },
    {
      id: '7',
      make: 'BMW',
      model: '3 Series',
      year: 2023,
      type: 'luxury',
      dailyRate: 110,
      image: 'https://images.pexels.com/photos/6894085/pexels-photo-6894085.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: false,
      description: 'The BMW 3 Series offers a perfect balance of luxury, performance, and handling for a dynamic driving experience.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation', 'Leather Seats', 'Sunroof']
    },
    {
      id: '8',
      make: 'Nissan',
      model: 'Rogue',
      year: 2022,
      type: 'suv',
      dailyRate: 75,
      image: 'https://images.pexels.com/photos/2920064/pexels-photo-2920064.jpeg',
      capacity: 5,
      transmission: 'automatic',
      fuel: 'gasoline',
      featured: false,
      description: 'The Nissan Rogue is a versatile compact SUV with ample cargo space and advanced safety features.',
      features: ['Air Conditioning', 'Bluetooth', 'USB Port', 'Backup Camera', 'Navigation']
    }
  ];
}

// Load featured cars on homepage
if (document.getElementById('featured-cars-container') && window.location.pathname === '/') {
  loadFeaturedCars();
}

async function loadFeaturedCars() {
  const container = document.getElementById('featured-cars-container');
  if (!container) return;

  try {
    const cars = await fetchCars();
    const featuredCars = cars.filter(car => car.featured);
    
    if (featuredCars.length === 0) {
      container.innerHTML = '<p class="text-center">No featured cars available at the moment.</p>';
      return;
    }

    let cardsHTML = '';
    featuredCars.forEach(car => {
      cardsHTML += `
        <div class="col-lg-3 col-md-6 mb-4">
          <div class="card car-card border-0 shadow-sm h-100">
            <img src="${car.image}" class="card-img-top" alt="${car.make} ${car.model}">
            <div class="card-body">
              <span class="badge bg-${getTypeColor(car.type)} car-type-badge">${capitalizeFirstLetter(car.type)}</span>
              <h5 class="card-title mt-2">${car.make} ${car.model}</h5>
              <p class="text-muted mb-2">${car.year} • ${capitalizeFirstLetter(car.transmission)} • ${capitalizeFirstLetter(car.fuel)}</p>
              <div class="d-flex align-items-center mb-3">
                <i class="bi bi-people me-2"></i>
                <span>${car.capacity} Seats</span>
              </div>
              <div class="d-flex justify-content-between align-items-center">
                <h6 class="mb-0">$${car.dailyRate}/day</h6>
                <a href="/pages/car-details.html?id=${car.id}" class="btn btn-sm btn-outline-primary">View Details</a>
              </div>
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = cardsHTML;

  } catch (error) {
    console.error('Error loading featured cars:', error);
    container.innerHTML = '<p class="text-center text-danger">Error loading featured cars. Please try again later.</p>';
  }
}

// Helper functions
function getTypeColor(type) {
  const typeColors = {
    'economy': 'success',
    'compact': 'info',
    'suv': 'warning',
    'luxury': 'primary',
    'van': 'secondary'
  };
  return typeColors[type] || 'secondary';
}

function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

// Handle search form on homepage
const searchForm = document.getElementById('search-form');
if (searchForm) {
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const pickupLocation = document.getElementById('pickup-location').value;
    const pickupDate = document.getElementById('pickup-date').value;
    const returnDate = document.getElementById('return-date').value;

    // Redirect to cars page with search parameters
    window.location.href = `/pages/cars.html?location=${pickupLocation}&pickup=${pickupDate}&return=${returnDate}`;
  });
}

// Export utility functions
export {
  checkLoginStatus,
  isAdmin,
  getUserName,
  handleLogin,
  handleRegister,
  handleLogout,
  getTypeColor,
  capitalizeFirstLetter
};